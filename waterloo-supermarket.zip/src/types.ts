export interface Product {
  id: string;
  name: string;
  category: string; // e.g. 'Fresh Produce', 'Dairy', 'Bakery', 'Frozen Food', 'Drinks', 'Snacks', 'Household', 'Personal Care', 'Travel Essentials', 'Souvenirs'
  price: number; // in GBP £
  originalPrice?: number;
  image: string;
  rating: number;
  reviewsCount: number;
  isFresh?: boolean;
  isPopular?: boolean;
  isOffer?: boolean;
  offerBadge?: string;
  unit: string; // e.g., '500g', '1L', 'Pack of 6', 'Each'
  description: string;
  dietary?: string[]; // e.g., ['Organic', 'Vegan', 'Gluten Free']
  inStock: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Category {
  id: string;
  name: string;
  description: string;
  image: string;
  iconName: string;
  itemCount: number;
  accentColor: string;
}

export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  icon: string;
  badge?: string;
  details: string[];
}

export interface Review {
  id: string;
  author: string;
  rating: number;
  date: string;
  comment: string;
  source: string;
  avatar: string;
  tag?: string;
}

export interface Landmark {
  name: string;
  distance: string;
  walkTime: string;
  icon: string;
  description: string;
}

export interface CurrencyRate {
  code: string;
  name: string;
  flag: string;
  buyRate: number; // GBP per unit
  sellRate: number;
}
