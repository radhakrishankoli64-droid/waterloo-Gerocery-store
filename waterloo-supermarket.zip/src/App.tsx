import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { CategoryGrid } from './components/CategoryGrid';
import { FeaturedProducts } from './components/FeaturedProducts';
import { OffersSection } from './components/OffersSection';
import { ServicesSection } from './components/ServicesSection';
import { LocationSection } from './components/LocationSection';
import { AboutSection } from './components/AboutSection';
import { ContactSection } from './components/ContactSection';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { ProductQuickView } from './components/ProductQuickView';
import { Footer } from './components/Footer';

import { PRODUCTS } from './data/products';
import { Product, CartItem } from './types';
import { CheckCircle2, ShoppingBag } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Cart state
  const [cart, setCart] = useState<CartItem[]>([]);
  const [cartDrawerOpen, setCartDrawerOpen] = useState<boolean>(false);
  const [checkoutModalOpen, setCheckoutModalOpen] = useState<boolean>(false);
  const [fulfillmentType, setFulfillmentType] = useState<'delivery' | 'pickup'>('delivery');
  const [promoDiscount, setPromoDiscount] = useState<number>(0);

  // Quick View Modal
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);

  // Notification Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  };

  // Add product to cart
  const handleAddToCart = (product: Product, quantityToAdd: number = 1) => {
    setCart((prevCart) => {
      const existing = prevCart.find((item) => item.product.id === product.id);
      if (existing) {
        return prevCart.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantityToAdd }
            : item
        );
      }
      return [...prevCart, { product, quantity: quantityToAdd }];
    });

    showToast(`Added ${quantityToAdd}x ${product.name} to cart`);
  };

  // Add bundle to cart
  const handleAddBundleToCart = (productsToAdd: Product[]) => {
    productsToAdd.forEach((p) => {
      handleAddToCart(p, 1);
    });
    setCartDrawerOpen(true);
  };

  // Update cart quantity
  const handleUpdateQuantity = (productId: string, delta: number) => {
    setCart((prevCart) => {
      return prevCart
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[];
    });
  };

  // Remove cart item
  const handleRemoveItem = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  // Proceed to Checkout
  const handleProceedToCheckout = (type: 'delivery' | 'pickup', discount: number) => {
    setFulfillmentType(type);
    setPromoDiscount(discount);
    setCartDrawerOpen(false);
    setCheckoutModalOpen(true);
  };

  // Clear cart on completion
  const handleOrderCompleted = () => {
    setCart([]);
    showToast('🎉 Order placed successfully! Live status updated.');
  };

  // Map cart product IDs for quantities
  const cartProductIds = cart.reduce((acc, item) => {
    acc[item.product.id] = item.quantity;
    return acc;
  }, {} as Record<string, number>);

  const cartTotalCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col selection:bg-emerald-500 selection:text-white">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-2xl border border-emerald-500/50 flex items-center gap-2.5 animate-in slide-in-from-bottom duration-200 text-xs font-semibold">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Navigation Bar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        cartCount={cartTotalCount}
        onOpenCart={() => setCartDrawerOpen(true)}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        products={PRODUCTS}
        onSelectProduct={(p) => setQuickViewProduct(p)}
        selectedCategory={selectedCategory}
        setSelectedCategory={setSelectedCategory}
      />

      {/* Main Views */}
      <main className="flex-1">
        {activeTab === 'home' && (
          <>
            <HeroSection
              onShopClick={() => {
                setActiveTab('shop');
                const element = document.getElementById('shop-section');
                element?.scrollIntoView({ behavior: 'smooth' });
              }}
              onOffersClick={() => setActiveTab('offers')}
              onServicesClick={() => setActiveTab('services')}
            />

            <CategoryGrid
              onSelectCategory={(catName) => {
                setSelectedCategory(catName);
                setActiveTab('shop');
              }}
            />

            <OffersSection
              onAddBundleToCart={handleAddBundleToCart}
              onNavigateShop={() => setActiveTab('shop')}
            />

            <FeaturedProducts
              products={PRODUCTS}
              onAddToCart={(p) => handleAddToCart(p, 1)}
              onQuickView={(p) => setQuickViewProduct(p)}
              selectedCategory={selectedCategory}
              setSelectedCategory={setSelectedCategory}
              cartProductIds={cartProductIds}
            />

            <ServicesSection />
            <LocationSection />
            <AboutSection />
            <ContactSection />
          </>
        )}

        {activeTab === 'shop' && (
          <div className="py-6">
            <FeaturedProducts
              products={PRODUCTS}
              onAddToCart={(p) => handleAddToCart(p, 1)}
              onQuickView={(p) => setQuickViewProduct(p)}
              selectedCategory={selectedCategory}
              setSelectedCategory={setSelectedCategory}
              cartProductIds={cartProductIds}
            />
          </div>
        )}

        {activeTab === 'categories' && (
          <div className="py-6 space-y-10">
            <CategoryGrid
              onSelectCategory={(catName) => {
                setSelectedCategory(catName);
                setActiveTab('shop');
              }}
            />
            <FeaturedProducts
              products={PRODUCTS}
              onAddToCart={(p) => handleAddToCart(p, 1)}
              onQuickView={(p) => setQuickViewProduct(p)}
              selectedCategory={selectedCategory}
              setSelectedCategory={setSelectedCategory}
              cartProductIds={cartProductIds}
            />
          </div>
        )}

        {activeTab === 'offers' && (
          <div className="py-6 space-y-10">
            <OffersSection
              onAddBundleToCart={handleAddBundleToCart}
              onNavigateShop={() => setActiveTab('shop')}
            />
            <FeaturedProducts
              products={PRODUCTS.filter((p) => p.isOffer)}
              onAddToCart={(p) => handleAddToCart(p, 1)}
              onQuickView={(p) => setQuickViewProduct(p)}
              selectedCategory="All"
              setSelectedCategory={setSelectedCategory}
              cartProductIds={cartProductIds}
            />
          </div>
        )}

        {activeTab === 'services' && (
          <div className="py-6 space-y-10">
            <ServicesSection />
            <LocationSection />
          </div>
        )}

        {activeTab === 'about' && (
          <div className="py-6 space-y-10">
            <AboutSection />
            <LocationSection />
          </div>
        )}

        {activeTab === 'contact' && (
          <div className="py-6 space-y-10">
            <LocationSection />
            <ContactSection />
          </div>
        )}
      </main>

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={cartDrawerOpen}
        onClose={() => setCartDrawerOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onProceedToCheckout={handleProceedToCheckout}
      />

      {/* Checkout Modal */}
      <CheckoutModal
        isOpen={checkoutModalOpen}
        onClose={() => setCheckoutModalOpen(false)}
        cart={cart}
        fulfillmentType={fulfillmentType}
        promoDiscount={promoDiscount}
        onOrderCompleted={handleOrderCompleted}
      />

      {/* Product Quick View Modal */}
      <ProductQuickView
        product={quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
        onAddToCart={(p, qty) => handleAddToCart(p, qty)}
      />

      {/* Footer */}
      <Footer onNavigateTab={(tab) => setActiveTab(tab)} />
    </div>
  );
}
