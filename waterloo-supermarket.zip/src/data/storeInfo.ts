import { Category, ServiceItem, Review, Landmark, CurrencyRate } from '../types';

export const STORE_DETAILS = {
  name: 'Waterloo Supermarket',
  tagline: 'Fresh Groceries, Everyday Essentials & Convenience – 24 Hours a Day',
  type: 'Convenience Store & Supermarket',
  address: '97–99 Westminster Bridge Road, London SE1 7HR, United Kingdom',
  shortAddress: '97-99 Westminster Bridge Rd, London SE1 7HR',
  postcode: 'SE1 7HR',
  phone: '+44 20 7928 8908',
  phoneFormatted: '020 7928 8908',
  email: 'info@waterloosupermarket.co.uk',
  rating: 4.4,
  reviewsCount: 291,
  openingHours: 'Open 24 Hours (Monday–Sunday)',
  status: 'Open 24/7',
  heroSubtitle: 'Serving the Waterloo community with fresh groceries, household essentials, snacks, beverages, and travel necessities in the heart of Central London.',
  about: `Waterloo Supermarket is a premier 24-hour convenience supermarket located in the heart of Waterloo, Central London. The store serves local residents, office workers, commuters, students, families, and tourists visiting nearby world-famous attractions such as the London Eye, Big Ben, and Waterloo Station. Customers can shop for groceries, fresh produce, snacks, chilled drinks, household essentials, souvenirs, and travel necessities at any time of the day or night.`,
  freeDeliveryThreshold: 15.00,
  deliveryFee: 2.50,
};

export const CATEGORIES: Category[] = [
  {
    id: 'fresh-produce',
    name: 'Fresh Produce',
    description: 'Fresh fruits, vegetables & seasonal items delivered daily.',
    image: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?auto=format&fit=crop&w=600&q=80',
    iconName: 'Apple',
    itemCount: 42,
    accentColor: 'bg-emerald-50 text-emerald-700 border-emerald-200'
  },
  {
    id: 'dairy-bakery',
    name: 'Dairy & Bakery',
    description: 'Fresh milk, artisanal cheeses, organic eggs, sourdough & French pastries.',
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=600&q=80',
    iconName: 'Milk',
    itemCount: 38,
    accentColor: 'bg-amber-50 text-amber-700 border-amber-200'
  },
  {
    id: 'drinks',
    name: 'Drinks & Beverages',
    description: 'Chilled soft drinks, mineral waters, energy drinks, juices & gourmet teas.',
    image: 'https://images.unsplash.com/photo-1527661591475-527312dd65f5?auto=format&fit=crop&w=600&q=80',
    iconName: 'Coffee',
    itemCount: 56,
    accentColor: 'bg-blue-50 text-blue-700 border-blue-200'
  },
  {
    id: 'frozen-food',
    name: 'Frozen Food',
    description: 'Frozen veggies, ready meals, gourmet pizzas & premium ice creams.',
    image: 'https://images.unsplash.com/photo-1563805042-7684c019e1cb?auto=format&fit=crop&w=600&q=80',
    iconName: 'Snowflake',
    itemCount: 24,
    accentColor: 'bg-cyan-50 text-cyan-700 border-cyan-200'
  },
  {
    id: 'snacks',
    name: 'Snacks & Confectionery',
    description: 'British crisps, premium chocolates, biscuits, nuts & sweet treats.',
    image: 'https://images.unsplash.com/photo-1582293041079-7814c2f12063?auto=format&fit=crop&w=600&q=80',
    iconName: 'Cookie',
    itemCount: 48,
    accentColor: 'bg-orange-50 text-orange-700 border-orange-200'
  },
  {
    id: 'household',
    name: 'Household & Cleaning',
    description: 'Kitchen paper, laundry, eco cleaners & everyday domestic supplies.',
    image: 'https://images.unsplash.com/photo-1583947215259-38e31be8751f?auto=format&fit=crop&w=600&q=80',
    iconName: 'Home',
    itemCount: 30,
    accentColor: 'bg-teal-50 text-teal-700 border-teal-200'
  },
  {
    id: 'personal-care',
    name: 'Personal Care',
    description: 'Shampoo, dental care, soaps, deodorants & grooming essentials.',
    image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=600&q=80',
    iconName: 'Sparkles',
    itemCount: 35,
    accentColor: 'bg-purple-50 text-purple-700 border-purple-200'
  },
  {
    id: 'travel-essentials',
    name: 'Travel Essentials',
    description: 'UK travel adapters, high-speed phone chargers, umbrellas & travel toiletries.',
    image: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=600&q=80',
    iconName: 'Smartphone',
    itemCount: 22,
    accentColor: 'bg-red-50 text-red-700 border-red-200'
  },
  {
    id: 'souvenirs',
    name: 'London Souvenirs',
    description: 'Authentic London keyrings, red bus magnets, mugs, tea tins & memorabilia.',
    image: 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?auto=format&fit=crop&w=600&q=80',
    iconName: 'Gift',
    itemCount: 29,
    accentColor: 'bg-rose-50 text-rose-700 border-rose-200'
  }
];

export const SERVICES: ServiceItem[] = [
  {
    id: 'service-247',
    title: '24/7 Shopping & Express Pickup',
    description: 'Never worry about store closing times. We are open 365 days a year, 24 hours a day.',
    icon: 'Clock',
    badge: 'Always Open',
    details: [
      'Late-night & early morning grocery access',
      'Express Click & Collect within 15 minutes',
      'Local SE1 & Waterloo hotel delivery service'
    ]
  },
  {
    id: 'service-keycutting',
    title: 'Instant Key Cutting Service',
    description: 'Quick key duplication while you wait or shop. Cylinder, Yale, mortice & padlock keys.',
    icon: 'Key',
    badge: 'In-Store Express',
    details: [
      'Precision brass & steel key duplication',
      'Residential, office & padlock key templates',
      'Bulk discount for local landlords & hotels'
    ]
  },
  {
    id: 'service-currency',
    title: 'Bureau de Change / Currency Exchange',
    description: 'Competitive zero-commission currency exchange for London tourists and commuters.',
    icon: 'Coins',
    badge: 'Best Rates SE1',
    details: [
      'Instant exchange for USD, EUR, JPY, AUD, CAD',
      'Zero fee commission on top world currencies',
      'Pre-order large amounts online for instant pickup'
    ]
  },
  {
    id: 'service-payments',
    title: 'Contactless & Card Payments',
    description: 'Seamless checkout with Apple Pay, Google Pay, Contactless & major international cards.',
    icon: 'CreditCard',
    badge: 'Fast Checkout',
    details: [
      'Accepting Visa, Mastercard, AMEX & UnionPay',
      'Tap to pay for instant sub-30 second transactions',
      'Digital receipt options available'
    ]
  },
  {
    id: 'service-offlicence',
    title: 'Licensed Off-Licence & Fine Wines',
    description: 'Wide selection of chilled beers, craft ciders, fine wines, gins, whiskies and spirits.',
    icon: 'Wine',
    badge: '24/7 License',
    details: [
      'Chilled craft IPA cans & popular lagers',
      'Curated French, Italian & New World wines',
      'Premium spirits and classic mixers'
    ]
  },
  {
    id: 'service-souvenirs',
    title: 'London Souvenir & Travel Corner',
    description: 'Pick up iconic London gifts, travel umbrellas, SIM cards and phone accessories.',
    icon: 'Compass',
    badge: 'Tourist Favorite',
    details: [
      'Big Ben & London Bus official memorabilia',
      'UK tourist SIM cards & power banks',
      'Heavy-duty umbrellas for London rain'
    ]
  }
];

export const NEARBY_LANDMARKS: Landmark[] = [
  {
    name: 'London Waterloo Station',
    distance: '250 meters',
    walkTime: '3 min walk',
    icon: 'Train',
    description: 'London’s busiest railway terminus connecting South London, Surrey & South West England.'
  },
  {
    name: 'The London Eye',
    distance: '450 meters',
    walkTime: '5 min walk',
    icon: 'FerrisWheel',
    description: 'Iconic observation wheel with panoramic views over the Thames and parliament.'
  },
  {
    name: 'Westminster Bridge & Big Ben',
    distance: '500 meters',
    walkTime: '6 min walk',
    icon: 'Landmark',
    description: 'Historic landmark bridge leading to Houses of Parliament and Elizabeth Tower.'
  },
  {
    name: 'South Bank Cultural Quarter',
    distance: '400 meters',
    walkTime: '5 min walk',
    icon: 'Compass',
    description: 'Vibrant riverside promenade with Royal Festival Hall, National Theatre and street food.'
  }
];

export const REVIEWS: Review[] = [
  {
    id: '1',
    author: 'David M. (Local Resident)',
    rating: 5,
    date: '2 days ago',
    comment: 'An absolute lifesaver in Waterloo! Open 24/7 and always stocked with fresh bread, milk, and great coffee. Friendly staff who know the regulars.',
    source: 'Google Review',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80',
    tag: 'Local Favorite'
  },
  {
    id: '2',
    author: 'Sarah Jenkins (Tourist from USA)',
    rating: 5,
    date: '1 week ago',
    comment: 'Staying at a nearby hotel near Westminster Bridge. We needed UK plug adapters, water, and snacks at 11 PM. Found everything here including great London souvenirs!',
    source: 'Google Review',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=120&q=80',
    tag: 'Verified Traveler'
  },
  {
    id: '3',
    author: 'James Patel (Commuter)',
    rating: 5,
    date: '2 weeks ago',
    comment: 'Super fast key cutting service! Got two house keys duplicated in under 3 minutes while I bought my lunch deal. Outstanding convenience.',
    source: 'Google Review',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=120&q=80',
    tag: 'Key Cutting Service'
  },
  {
    id: '4',
    author: 'Elena Rostova',
    rating: 4,
    date: '3 weeks ago',
    comment: 'Great selection of foreign snacks, fresh fruit, and late night drinks right by Waterloo station. Very clean and well organised store.',
    source: 'Google Review',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=120&q=80',
    tag: 'Verified Customer'
  }
];

export const CURRENCY_RATES: CurrencyRate[] = [
  { code: 'EUR', name: 'Euro', flag: '🇪🇺', buyRate: 1.18, sellRate: 1.15 },
  { code: 'USD', name: 'US Dollar', flag: '🇺🇸', buyRate: 1.29, sellRate: 1.26 },
  { code: 'JPY', name: 'Japanese Yen', flag: '🇯🇵', buyRate: 192.50, sellRate: 185.00 },
  { code: 'CAD', name: 'Canadian Dollar', flag: '🇨🇦', buyRate: 1.76, sellRate: 1.70 },
  { code: 'AUD', name: 'Australian Dollar', flag: '🇦🇺', buyRate: 1.95, sellRate: 1.88 },
  { code: 'CHF', name: 'Swiss Franc', flag: '🇨🇭', buyRate: 1.12, sellRate: 1.08 }
];
