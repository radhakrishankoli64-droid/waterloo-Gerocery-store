import React, { useState } from 'react';
import { STORE_DETAILS } from '../data/storeInfo';
import { MapPin, Phone, Mail, Clock, Send, CheckCircle2 } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    subject: 'General Inquiry',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) return;
    setSubmitted(true);
  };

  return (
    <section id="contact-section" className="py-12 md:py-16 bg-stone-900 text-white border-b border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          
          {/* Contact Details */}
          <div className="lg:col-span-5 space-y-6">
            <div>
              <span className="inline-block bg-[#2D5A27]/30 text-emerald-300 border border-[#2D5A27]/50 text-xs font-bold uppercase tracking-widest px-3.5 py-1 rounded-full mb-3">
                Get In Touch
              </span>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif text-white tracking-tight">
                Contact Waterloo Supermarket
              </h2>
              <p className="text-stone-300 text-sm sm:text-base mt-3 leading-relaxed">
                We are open 24 hours a day, 7 days a week. Visit us in person, give us a call, or send us a message below.
              </p>
            </div>

            <div className="space-y-4">
              <div className="bg-stone-800/80 p-4 rounded-xl border border-stone-700 flex items-start gap-3">
                <div className="w-9 h-9 rounded-full bg-[#2D5A27]/20 text-emerald-400 border border-[#2D5A27]/40 flex items-center justify-center shrink-0 font-bold">
                  <MapPin className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-stone-400 uppercase tracking-widest">Store Address</h3>
                  <p className="text-sm font-semibold text-white mt-0.5">{STORE_DETAILS.address}</p>
                </div>
              </div>

              <div className="bg-stone-800/80 p-4 rounded-xl border border-stone-700 flex items-start gap-3">
                <div className="w-9 h-9 rounded-full bg-[#2D5A27]/20 text-emerald-400 border border-[#2D5A27]/40 flex items-center justify-center shrink-0 font-bold">
                  <Phone className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-stone-400 uppercase tracking-widest">24/7 Telephone</h3>
                  <a href={`tel:${STORE_DETAILS.phone}`} className="text-sm font-semibold text-emerald-400 hover:underline mt-0.5 block">
                    {STORE_DETAILS.phoneFormatted}
                  </a>
                </div>
              </div>

              <div className="bg-stone-800/80 p-4 rounded-xl border border-stone-700 flex items-start gap-3">
                <div className="w-9 h-9 rounded-full bg-[#2D5A27]/20 text-emerald-400 border border-[#2D5A27]/40 flex items-center justify-center shrink-0 font-bold">
                  <Clock className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-stone-400 uppercase tracking-widest">Opening Hours</h3>
                  <p className="text-sm font-semibold text-emerald-400 mt-0.5 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                    {STORE_DETAILS.openingHours}
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-stone-950 p-4 rounded-xl border border-stone-800 text-xs text-stone-400 space-y-1">
              <p className="font-bold text-white">📍 Nearby Transport Connections:</p>
              <p>• London Waterloo Station (Bakerloo, Jubilee, Northern, W&C, National Rail)</p>
              <p>• Westminster Station (Circle, District, Jubilee)</p>
              <p>• Bus Stops: Westminster Bridge Road (Routes 12, 53, 148, 159, 211, 453)</p>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-7">
            <div className="bg-stone-800/90 rounded-2xl p-6 sm:p-8 border border-stone-700 shadow-xs">
              <h3 className="text-xl font-bold text-white mb-1">Send Us a Direct Message</h3>
              <p className="text-xs text-stone-400 mb-6">
                Have a question about product availability, bulk hotel orders, key cutting, or currency exchange?
              </p>

              {!submitted ? (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-stone-300 mb-1">Your Full Name *</label>
                      <input
                        type="text"
                        required
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                        placeholder="John Smith"
                        className="w-full bg-stone-950 border border-stone-700 rounded-lg px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#2D5A27]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-stone-300 mb-1">Email Address *</label>
                      <input
                        type="email"
                        required
                        value={form.email}
                        onChange={(e) => setForm({ ...form, email: e.target.value })}
                        placeholder="john@example.com"
                        className="w-full bg-stone-950 border border-stone-700 rounded-lg px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#2D5A27]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-stone-300 mb-1">Phone Number</label>
                      <input
                        type="tel"
                        value={form.phone}
                        onChange={(e) => setForm({ ...form, phone: e.target.value })}
                        placeholder="+44 7123 456789"
                        className="w-full bg-stone-950 border border-stone-700 rounded-lg px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#2D5A27]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-stone-300 mb-1">Subject</label>
                      <select
                        value={form.subject}
                        onChange={(e) => setForm({ ...form, subject: e.target.value })}
                        className="w-full bg-stone-950 border border-stone-700 rounded-lg px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#2D5A27]"
                      >
                        <option value="General Inquiry">General Inquiry</option>
                        <option value="Key Cutting Request">Key Cutting Request</option>
                        <option value="Currency Exchange Pre-Order">Currency Exchange Pre-Order</option>
                        <option value="Hotel Bulk Order">Hotel Bulk Order / Catering</option>
                        <option value="Feedback">Store Feedback</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-300 mb-1">Message *</label>
                    <textarea
                      required
                      rows={4}
                      value={form.message}
                      onChange={(e) => setForm({ ...form, message: e.target.value })}
                      placeholder="Write your message or inquiry here..."
                      className="w-full bg-stone-950 border border-stone-700 rounded-lg p-3 text-xs text-white outline-none focus:border-[#2D5A27]"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-[#2D5A27] hover:bg-[#23471f] text-white font-bold py-3 rounded-lg text-xs transition-all flex items-center justify-center gap-2 shadow-xs"
                  >
                    <Send className="w-4 h-4" />
                    <span>Send Message to Waterloo Store</span>
                  </button>
                </form>
              ) : (
                <div className="bg-stone-950 border border-[#2D5A27] rounded-xl p-6 text-center space-y-3">
                  <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
                  <h4 className="text-base font-bold text-white">Message Sent Successfully!</h4>
                  <p className="text-xs text-stone-300 max-w-md mx-auto">
                    Thank you for contacting Waterloo Supermarket. Our team will get back to you shortly. You can also visit us anytime 24/7 at 97-99 Westminster Bridge Rd!
                  </p>
                  <button
                    onClick={() => setSubmitted(false)}
                    className="text-xs font-bold text-emerald-400 underline pt-2"
                  >
                    Send another message
                  </button>
                </div>
              )}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
