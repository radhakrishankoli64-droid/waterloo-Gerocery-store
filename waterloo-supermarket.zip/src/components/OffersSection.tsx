import React from 'react';
import { SPECIAL_OFFERS } from '../data/products';
import { PRODUCTS } from '../data/products';
import { Product } from '../types';
import { Percent, Check, Sparkles, ShoppingBag, ArrowRight } from 'lucide-react';

interface OffersSectionProps {
  onAddBundleToCart: (products: Product[]) => void;
  onNavigateShop: () => void;
}

export const OffersSection: React.FC<OffersSectionProps> = ({ onAddBundleToCart, onNavigateShop }) => {
  const getBundleProducts = (bundleId: string): Product[] => {
    if (bundleId === 'offer-1') {
      // Tourist pack: Cable, Adapter, Umbrella, Water, Cadbury
      return PRODUCTS.filter(p => ['prod-25', 'prod-26', 'prod-27', 'prod-12', 'prod-19'].includes(p.id));
    } else if (bundleId === 'offer-2') {
      // Midnight pack: Ice Cream, Crisps, Coke, Cadbury
      return PRODUCTS.filter(p => ['prod-17', 'prod-18', 'prod-13', 'prod-19'].includes(p.id));
    } else {
      // Breakfast combo: Croissants, Milk, Tea, Apples
      return PRODUCTS.filter(p => ['prod-08', 'prod-05', 'prod-15', 'prod-01'].includes(p.id));
    }
  };

  return (
    <section className="py-12 md:py-16 bg-[#F8F7F3] border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <span className="inline-flex items-center gap-1.5 bg-[#2D5A27]/10 text-[#2D5A27] font-bold text-xs uppercase tracking-widest px-3.5 py-1 rounded-full border border-[#2D5A27]/20">
              <Percent className="w-3.5 h-3.5" />
              Special Waterloo Bundles & Deals
            </span>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-serif text-stone-800 mt-3 tracking-tight">
              Exclusive Value Saver Packs
            </h2>
            <p className="text-stone-600 text-sm sm:text-base mt-2 max-w-xl">
              Specially curated combos for London tourists, late-night hotel guests, and local morning commuters at discounted bundle prices.
            </p>
          </div>

          <button
            onClick={onNavigateShop}
            className="inline-flex items-center gap-2 text-xs font-bold text-stone-800 hover:text-stone-900 bg-white border border-stone-300 px-4 py-2.5 rounded-lg hover:bg-stone-50 transition-all shadow-xs"
          >
            <span>View All Deals in Shop</span>
            <ArrowRight className="w-4 h-4 text-[#2D5A27]" />
          </button>
        </div>

        {/* Offer Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {SPECIAL_OFFERS.map((offer) => {
            const bundleItems = getBundleProducts(offer.id);

            return (
              <div
                key={offer.id}
                className="bg-white rounded-2xl border border-stone-200 shadow-xs hover:shadow-md transition-all duration-200 overflow-hidden flex flex-col justify-between"
              >
                <div>
                  {/* Top Image Banner */}
                  <div className="relative h-44 w-full bg-stone-900">
                    <img
                      src={offer.image}
                      alt={offer.title}
                      className="w-full h-full object-cover opacity-90"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-transparent to-transparent" />
                    
                    <span className="absolute top-3 left-3 bg-[#2D5A27] text-white text-[10px] font-extrabold px-2.5 py-1 rounded-md shadow-xs uppercase tracking-wide">
                      {offer.badge}
                    </span>

                    <span className="absolute top-3 right-3 bg-amber-300 text-stone-900 text-xs font-bold px-2 py-1 rounded shadow-xs">
                      {offer.savings}
                    </span>

                    <div className="absolute bottom-3 left-3 right-3 text-white">
                      <h3 className="text-lg font-bold">{offer.title}</h3>
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-5 space-y-4">
                    <p className="text-xs text-stone-600 italic">
                      "{offer.description}"
                    </p>

                    <div>
                      <h4 className="text-xs font-bold text-stone-900 uppercase tracking-wider mb-2">
                        Bundle Contents ({offer.items.length} Items):
                      </h4>
                      <ul className="space-y-1.5 text-xs text-stone-700">
                        {offer.items.map((item, idx) => (
                          <li key={idx} className="flex items-center gap-2">
                            <Check className="w-3.5 h-3.5 text-[#2D5A27] shrink-0" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Bundle Footer */}
                <div className="p-5 pt-0 border-t border-stone-100 bg-[#F8F7F3] mt-4">
                  <div className="flex items-baseline justify-between my-3">
                    <div>
                      <span className="text-xs text-stone-400 block font-semibold uppercase tracking-wider">Bundle Price</span>
                      <div className="flex items-baseline gap-2">
                        <span className="text-2xl font-extrabold text-stone-900 font-mono">
                          £{offer.price.toFixed(2)}
                        </span>
                        <span className="text-xs text-stone-400 line-through font-mono">
                          £{offer.originalPrice.toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => onAddBundleToCart(bundleItems)}
                    className="w-full bg-stone-900 hover:bg-stone-800 text-white font-bold py-3 px-4 rounded-lg text-xs flex items-center justify-center gap-2 shadow-xs transition-all"
                  >
                    <ShoppingBag className="w-4 h-4 text-stone-300" />
                    <span>Add Complete Bundle to Cart</span>
                  </button>
                </div>

              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
