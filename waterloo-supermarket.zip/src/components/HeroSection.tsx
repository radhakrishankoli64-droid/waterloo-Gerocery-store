import React from 'react';
import { 
  ShoppingBag, 
  Percent, 
  MapPin, 
  Clock, 
  ShieldCheck, 
  Truck, 
  Key, 
  Coins, 
  Star,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { STORE_DETAILS } from '../data/storeInfo';

interface HeroSectionProps {
  onShopClick: () => void;
  onOffersClick: () => void;
  onServicesClick: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onShopClick,
  onOffersClick,
  onServicesClick
}) => {
  return (
    <section className="bg-[#F8F7F3] text-stone-900 py-12 md:py-16 lg:py-20 border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          {/* Left Hero Content */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Top Badge */}
            <div className="inline-flex items-center gap-2 bg-[#2D5A27]/10 text-[#2D5A27] px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest border border-[#2D5A27]/20">
              <span className="w-2 h-2 rounded-full bg-[#2D5A27] animate-pulse"></span>
              <span>Open 24 Hours · London SE1</span>
            </div>

            {/* Main Serif Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-serif leading-[1.1] text-stone-800 tracking-tight">
              Fresh Groceries,<br />
              <span className="italic text-[#2D5A27]">Everyday</span> Essentials.
            </h1>

            {/* Subtitle */}
            <p className="text-stone-600 text-base sm:text-lg max-w-xl leading-relaxed">
              Serving the Waterloo & Westminster community with premium fresh produce, household staples, key cutting, and currency exchange 24/7.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={onShopClick}
                className="px-8 py-4 bg-stone-900 text-white font-bold rounded-lg shadow-md hover:bg-stone-800 transition-colors inline-flex items-center gap-2 text-sm"
              >
                <ShoppingBag className="w-4 h-4 text-stone-300" />
                <span>Shop Fresh Now</span>
              </button>

              <button
                onClick={onOffersClick}
                className="px-8 py-4 border border-stone-300 text-stone-800 font-bold rounded-lg hover:bg-stone-100/60 transition-colors inline-flex items-center gap-2 text-sm"
              >
                <Percent className="w-4 h-4 text-[#2D5A27]" />
                <span>View Special Offers</span>
              </button>

              <button
                onClick={onServicesClick}
                className="px-6 py-4 bg-white border border-stone-200 text-stone-700 font-bold rounded-lg hover:bg-stone-50 transition-colors inline-flex items-center gap-2 text-sm"
              >
                <Key className="w-4 h-4 text-amber-700" />
                <span>24/7 Services</span>
              </button>
            </div>

            {/* Trust Markers */}
            <div className="pt-6 border-t border-stone-200 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs text-stone-600">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-[#2D5A27]/10 text-[#2D5A27] flex items-center justify-center shrink-0 font-bold">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-bold text-stone-800">24/7 Open</p>
                  <p className="text-[11px] text-stone-500">Mon–Sun Always</p>
                </div>
              </div>

              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-[#2D5A27]/10 text-[#2D5A27] flex items-center justify-center shrink-0 font-bold">
                  <Truck className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-bold text-stone-800">30-Min Delivery</p>
                  <p className="text-[11px] text-stone-500">SE1 Express Post</p>
                </div>
              </div>

              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-[#2D5A27]/10 text-[#2D5A27] flex items-center justify-center shrink-0 font-bold">
                  <Coins className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-bold text-stone-800">Currency Exchange</p>
                  <p className="text-[11px] text-stone-500">0% Commission</p>
                </div>
              </div>

              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-[#2D5A27]/10 text-[#2D5A27] flex items-center justify-center shrink-0 font-bold">
                  <Key className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-bold text-stone-800">Key Cutting</p>
                  <p className="text-[11px] text-stone-500">Instant Service</p>
                </div>
              </div>
            </div>

          </div>

          {/* Right Hero Clean Minimalist Graphic Grid */}
          <div className="lg:col-span-5">
            <div className="bg-white rounded-3xl shadow-xs border border-stone-200 p-6 sm:p-8 grid grid-cols-2 grid-rows-2 gap-4">
              
              <div 
                onClick={onShopClick}
                className="bg-[#F3F4ED] rounded-2xl flex flex-col items-center justify-center p-6 text-center group cursor-pointer hover:shadow-md transition-all border border-stone-200/50"
              >
                <div className="w-16 h-16 bg-white rounded-full mb-3 flex items-center justify-center text-2xl shadow-xs group-hover:scale-110 transition-transform">
                  🍎
                </div>
                <span className="font-bold text-stone-800 text-sm">Fresh Produce</span>
                <span className="text-[11px] text-stone-500 mt-0.5">Organic & Daily</span>
              </div>

              <div 
                onClick={onShopClick}
                className="bg-[#FDF7F2] rounded-2xl flex flex-col items-center justify-center p-6 text-center group cursor-pointer hover:shadow-md transition-all border border-stone-200/50"
              >
                <div className="w-16 h-16 bg-white rounded-full mb-3 flex items-center justify-center text-2xl shadow-xs group-hover:scale-110 transition-transform">
                  🥐
                </div>
                <span className="font-bold text-stone-800 text-sm">Artisan Bakery</span>
                <span className="text-[11px] text-stone-500 mt-0.5">Fresh Oven Baked</span>
              </div>

              <div 
                onClick={onShopClick}
                className="bg-[#F2F7FD] rounded-2xl flex flex-col items-center justify-center p-6 text-center group cursor-pointer hover:shadow-md transition-all border border-stone-200/50"
              >
                <div className="w-16 h-16 bg-white rounded-full mb-3 flex items-center justify-center text-2xl shadow-xs group-hover:scale-110 transition-transform">
                  🧀
                </div>
                <span className="font-bold text-stone-800 text-sm">Dairy & Chilled</span>
                <span className="text-[11px] text-stone-500 mt-0.5">Farm Fresh Milk</span>
              </div>

              <div 
                onClick={onServicesClick}
                className="bg-[#F5F2FD] rounded-2xl flex flex-col items-center justify-center p-6 text-center group cursor-pointer hover:shadow-md transition-all border border-stone-200/50"
              >
                <div className="w-16 h-16 bg-white rounded-full mb-3 flex items-center justify-center text-2xl shadow-xs group-hover:scale-110 transition-transform">
                  🔌
                </div>
                <span className="font-bold text-stone-800 text-sm">Travel & Chargers</span>
                <span className="text-[11px] text-stone-500 mt-0.5">24/7 Essentials</span>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
