import React from 'react';
import { CATEGORIES } from '../data/storeInfo';
import { 
  Apple, 
  Milk, 
  Coffee, 
  Snowflake, 
  Cookie, 
  Home, 
  Sparkles, 
  Smartphone, 
  Gift,
  ArrowRight
} from 'lucide-react';

interface CategoryGridProps {
  onSelectCategory: (categoryName: string) => void;
}

const iconMap: Record<string, React.ReactNode> = {
  Apple: <Apple className="w-5 h-5" />,
  Milk: <Milk className="w-5 h-5" />,
  Coffee: <Coffee className="w-5 h-5" />,
  Snowflake: <Snowflake className="w-5 h-5" />,
  Cookie: <Cookie className="w-5 h-5" />,
  Home: <Home className="w-5 h-5" />,
  Sparkles: <Sparkles className="w-5 h-5" />,
  Smartphone: <Smartphone className="w-5 h-5" />,
  Gift: <Gift className="w-5 h-5" />
};

export const CategoryGrid: React.FC<CategoryGridProps> = ({ onSelectCategory }) => {
  return (
    <section className="py-12 md:py-16 bg-[#F8F7F3] border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
          <div>
            <span className="text-[#2D5A27] font-bold text-xs uppercase tracking-widest bg-[#2D5A27]/10 border border-[#2D5A27]/20 px-3.5 py-1 rounded-full">
              Aisle Categories
            </span>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-serif text-stone-800 mt-3 tracking-tight">
              Explore Our Store Aisles
            </h2>
            <p className="text-stone-600 text-sm sm:text-base mt-2 max-w-xl">
              From fresh farm fruits to late-night travel chargers and London souvenirs, find everything in-store or order for local express delivery.
            </p>
          </div>
        </div>

        {/* Category Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 gap-4 sm:gap-6">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.name)}
              className="group text-left bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs hover:shadow-md hover:border-[#2D5A27] transition-all duration-200 flex flex-col justify-between"
            >
              <div className="relative h-36 sm:h-44 w-full overflow-hidden bg-stone-100">
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-stone-900/20 to-transparent" />
                
                {/* Category Icon Pill */}
                <div className="absolute top-3 left-3 bg-white/95 text-stone-800 p-2 rounded-xl shadow-xs border border-stone-200">
                  {iconMap[cat.iconName] || <Sparkles className="w-5 h-5 text-[#2D5A27]" />}
                </div>

                <div className="absolute bottom-3 left-3 right-3 text-white">
                  <h3 className="text-base sm:text-lg font-bold text-white group-hover:text-amber-200 transition-colors">
                    {cat.name}
                  </h3>
                  <p className="text-xs text-stone-200 opacity-90 line-clamp-1 mt-0.5 font-normal">
                    {cat.description}
                  </p>
                </div>
              </div>

              <div className="p-3.5 bg-white flex items-center justify-between text-xs font-bold text-stone-700">
                <span className="text-[#2D5A27]">{cat.itemCount}+ In-Stock Items</span>
                <span className="text-stone-400 group-hover:text-[#2D5A27] group-hover:translate-x-1 transition-all flex items-center gap-1">
                  Browse <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </button>
          ))}
        </div>

      </div>
    </section>
  );
};
