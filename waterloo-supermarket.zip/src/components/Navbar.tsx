import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Search, 
  Clock, 
  MapPin, 
  Phone, 
  Menu, 
  X, 
  Sparkles, 
  Percent, 
  Key, 
  Coins, 
  CheckCircle2,
  ChevronRight
} from 'lucide-react';
import { STORE_DETAILS } from '../data/storeInfo';
import { Product } from '../types';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  cartCount: number;
  onOpenCart: () => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  products: Product[];
  onSelectProduct: (product: Product) => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  cartCount,
  onOpenCart,
  searchQuery,
  setSearchQuery,
  products,
  onSelectProduct,
  setSelectedCategory
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchFocused, setSearchFocused] = useState(false);

  const filteredSearchResults = searchQuery.trim()
    ? products.filter(p => 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.category.toLowerCase().includes(searchQuery.toLowerCase())
      ).slice(0, 5)
    : [];

  const handleNavClick = (tabId: string) => {
    setActiveTab(tabId);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      {/* Top Banner Bar */}
      <div className="bg-[#2D5A27] text-stone-100 text-xs py-2 px-4">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-3 overflow-x-auto whitespace-nowrap">
            <span className="inline-flex items-center gap-1.5 bg-white/15 text-white px-2.5 py-0.5 rounded-full font-medium text-[11px]">
              <span className="w-2 h-2 rounded-full bg-emerald-300 animate-pulse"></span>
              {STORE_DETAILS.status}
            </span>
            <span className="hidden md:inline text-white/40">•</span>
            <span className="hidden md:inline flex items-center gap-1 text-stone-100">
              <MapPin className="w-3.5 h-3.5 text-stone-200" />
              {STORE_DETAILS.shortAddress}
            </span>
            <span className="text-white/40">•</span>
            <span className="text-stone-100 font-medium">3 mins from Waterloo Station</span>
          </div>

          <div className="flex items-center gap-4 text-[11px] shrink-0">
            <a 
              href={`tel:${STORE_DETAILS.phone}`} 
              className="hover:text-amber-200 transition-colors flex items-center gap-1 font-medium text-stone-100"
            >
              <Phone className="w-3 h-3 text-stone-200" />
              {STORE_DETAILS.phoneFormatted}
            </a>
            <span className="text-white/30">|</span>
            <span className="text-amber-200 font-semibold flex items-center gap-1">
              ⭐ 4.4/5 (291 reviews)
            </span>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5">
        <div className="flex items-center justify-between gap-4">
          
          {/* Logo */}
          <button 
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3 text-left group focus:outline-none"
          >
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#2D5A27] text-white flex items-center justify-center font-bold text-xl shadow-xs group-hover:scale-105 transition-transform">
              W
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-lg sm:text-xl text-stone-900 tracking-tight leading-none uppercase">
                  WATERLOO <span className="text-[#2D5A27]">SUPERMARKET</span>
                </span>
                <span className="text-[10px] bg-stone-100 text-stone-700 font-bold px-1.5 py-0.5 rounded border border-stone-200">
                  24H
                </span>
              </div>
              <span className="text-[11px] font-medium text-stone-500 block tracking-wider uppercase mt-0.5">
                Convenience & Groceries
              </span>
            </div>
          </button>

          {/* Search Bar */}
          <div className="relative flex-1 max-w-md hidden md:block">
            <div className="relative">
              <input
                type="text"
                placeholder="Search fresh produce, drinks, essentials..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => setSearchFocused(true)}
                onBlur={() => setTimeout(() => setSearchFocused(false), 200)}
                className="w-full bg-[#F8F7F3] hover:bg-stone-50 focus:bg-white text-stone-900 text-sm pl-10 pr-4 py-2 rounded-full border border-stone-200 focus:border-[#2D5A27] focus:ring-2 focus:ring-[#2D5A27]/20 transition-all outline-none"
              />
              <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 text-xs bg-stone-200 rounded-full w-4 h-4 flex items-center justify-center"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Instant Search Dropdown */}
            {searchFocused && filteredSearchResults.length > 0 && (
              <div className="absolute left-0 right-0 top-full mt-2 bg-white rounded-2xl shadow-xl border border-stone-200 overflow-hidden z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="px-3.5 py-2 bg-stone-50 text-xs font-bold text-stone-500 border-b border-stone-100 flex justify-between">
                  <span>Matching Products</span>
                  <span className="text-[#2D5A27]">{filteredSearchResults.length} found</span>
                </div>
                <div className="divide-y divide-stone-100">
                  {filteredSearchResults.map((prod) => (
                    <button
                      key={prod.id}
                      onClick={() => {
                        onSelectProduct(prod);
                        setSearchQuery('');
                      }}
                      className="w-full text-left p-2.5 flex items-center gap-3 hover:bg-stone-50 transition-colors"
                    >
                      <img src={prod.image} alt={prod.name} className="w-10 h-10 object-cover rounded-lg border border-stone-200 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-bold text-stone-800 truncate">{prod.name}</p>
                        <p className="text-[11px] text-stone-500">{prod.category} • {prod.unit}</p>
                      </div>
                      <span className="text-xs font-bold text-[#2D5A27] font-mono">£{prod.price.toFixed(2)}</span>
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => {
                    setActiveTab('shop');
                    setSearchFocused(false);
                  }}
                  className="w-full text-center py-2.5 bg-stone-50 text-xs text-[#2D5A27] font-bold hover:underline border-t border-stone-100"
                >
                  View all results in Shop →
                </button>
              </div>
            )}
          </div>

          {/* Action Tools & Cart */}
          <div className="flex items-center gap-2 sm:gap-3">
            <button
              onClick={() => handleNavClick('services')}
              className="hidden lg:flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors"
              title="Currency Exchange & Key Cutting"
            >
              <Coins className="w-3.5 h-3.5 text-amber-700" />
              <span>Currency Exchange</span>
            </button>

            <button
              onClick={() => handleNavClick('offers')}
              className="hidden sm:flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-[#2D5A27] bg-[#2D5A27]/10 hover:bg-[#2D5A27]/20 border border-[#2D5A27]/20 rounded-lg transition-colors"
            >
              <Percent className="w-3.5 h-3.5 text-[#2D5A27]" />
              <span>Special Offers</span>
            </button>

            {/* Cart Button */}
            <button
              onClick={onOpenCart}
              id="cart-button"
              className="relative flex items-center gap-2 bg-stone-900 hover:bg-stone-800 text-white px-4 py-2.5 rounded-lg font-bold text-xs shadow-sm transition-all"
            >
              <ShoppingBag className="w-4 h-4 text-stone-200" />
              <span className="hidden sm:inline">Cart</span>
              {cartCount > 0 && (
                <span className="bg-[#2D5A27] text-white text-[11px] font-bold w-5 h-5 rounded-full flex items-center justify-center animate-bounce">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-stone-700 hover:bg-stone-100 rounded-lg"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Search input */}
        <div className="mt-2 md:hidden">
          <div className="relative">
            <input
              type="text"
              placeholder="Search products, groceries, travel items..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#F8F7F3] text-stone-900 text-sm pl-9 pr-4 py-2 rounded-lg border border-stone-200 outline-none focus:ring-2 focus:ring-[#2D5A27]/20"
            />
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
          </div>
        </div>
      </div>

      {/* Primary Navigation Tabs */}
      <nav className="border-t border-stone-200 bg-white hidden md:block">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center space-x-2 py-2 text-sm font-medium">
            {[
              { id: 'home', label: 'Home' },
              { id: 'shop', label: 'Shop' },
              { id: 'categories', label: 'Categories' },
              { id: 'offers', label: 'Offers', badge: 'Deals' },
              { id: 'services', label: '24/7 Services' },
              { id: 'about', label: 'About Us' },
              { id: 'contact', label: 'Contact' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => handleNavClick(tab.id)}
                className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 ${
                  activeTab === tab.id
                    ? 'bg-[#2D5A27] text-white shadow-xs'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
                }`}
              >
                <span>{tab.label}</span>
                {tab.badge && (
                  <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full ${
                    activeTab === tab.id ? 'bg-amber-300 text-stone-900' : 'bg-[#2D5A27]/10 text-[#2D5A27]'
                  }`}>
                    {tab.badge}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 py-4 space-y-2 animate-in slide-in-from-top duration-200">
          <div className="text-xs font-semibold uppercase text-slate-400 px-3 pb-1">Navigation</div>
          {[
            { id: 'home', label: 'Home' },
            { id: 'shop', label: 'Shop Products' },
            { id: 'categories', label: 'Browse Categories' },
            { id: 'offers', label: 'Special Offers & Bundles' },
            { id: 'services', label: 'Key Cutting & Currency Exchange' },
            { id: 'about', label: 'About Waterloo Supermarket' },
            { id: 'contact', label: 'Contact Details & Map' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => handleNavClick(tab.id)}
              className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium flex items-center justify-between ${
                activeTab === tab.id
                  ? 'bg-emerald-50 text-emerald-800 font-bold border-l-4 border-emerald-600'
                  : 'text-slate-700 hover:bg-slate-50'
              }`}
            >
              <span>{tab.label}</span>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </button>
          ))}

          <div className="pt-3 border-t border-slate-100 text-xs text-slate-600 space-y-1.5 px-3">
            <p className="font-semibold text-slate-900">📍 97–99 Westminster Bridge Rd, London SE1 7HR</p>
            <p>⏰ Open 24 Hours • 7 Days a Week</p>
            <p>📞 Call: +44 20 7928 8908</p>
          </div>
        </div>
      )}
    </header>
  );
};
