import React from 'react';
import { STORE_DETAILS, REVIEWS } from '../data/storeInfo';
import { 
  ShieldCheck, 
  Clock, 
  HeartHandshake, 
  MapPin, 
  Sparkles, 
  ShoppingBag,
  Star,
  Quote
} from 'lucide-react';

export const AboutSection: React.FC = () => {
  return (
    <section id="about-section" className="py-12 md:py-16 bg-white border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main About Story */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center mb-16">
          <div className="lg:col-span-6 space-y-4">
            <span className="inline-block bg-[#2D5A27]/10 text-[#2D5A27] text-xs font-bold uppercase tracking-widest px-3.5 py-1 rounded-full border border-[#2D5A27]/20">
              About Waterloo Supermarket
            </span>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif text-stone-800 tracking-tight leading-tight">
              Central London's Trusted 24-Hour Supermarket & Convenience Store
            </h2>
            <p className="text-stone-600 text-sm sm:text-base leading-relaxed">
              {STORE_DETAILS.about}
            </p>
            <p className="text-stone-600 text-sm sm:text-base leading-relaxed">
              Whether you need fresh organic milk at 6:00 AM before catching a train from Waterloo Station, a windproof umbrella and travel charger on a rainy London afternoon, or late-night snacks and ice cream delivered to your hotel near Westminster Bridge, we are here for you 24 hours a day, 365 days a year.
            </p>

            <div className="pt-2 grid grid-cols-2 gap-4 text-xs font-bold text-stone-800">
              <div className="flex items-center gap-2 bg-[#F8F7F3] p-3.5 rounded-xl border border-stone-200">
                <Clock className="w-5 h-5 text-[#2D5A27]" />
                <span>Open 24 Hours Daily</span>
              </div>
              <div className="flex items-center gap-2 bg-[#F8F7F3] p-3.5 rounded-xl border border-stone-200">
                <MapPin className="w-5 h-5 text-[#2D5A27]" />
                <span>Heart of Waterloo SE1</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="relative rounded-2xl overflow-hidden shadow-md border border-stone-200">
              <img
                src="https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=800&q=80"
                alt="Waterloo Supermarket storefront"
                className="w-full h-80 sm:h-96 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-transparent to-transparent" />
              
              <div className="absolute bottom-4 left-4 right-4 text-white p-4 bg-stone-900/90 rounded-xl border border-stone-700">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-sm text-amber-200">Waterloo Supermarket</h3>
                    <p className="text-xs text-stone-300">97–99 Westminster Bridge Road, London SE1 7HR</p>
                  </div>
                  <span className="bg-[#2D5A27] text-white text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider">
                    24/7 Verified
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Why Choose Waterloo Supermarket */}
        <div className="bg-[#F8F7F3] rounded-2xl p-8 border border-stone-200 mb-16">
          <div className="text-center max-w-2xl mx-auto mb-8">
            <h3 className="text-2xl sm:text-3xl font-serif text-stone-800">Why Choose Waterloo Supermarket</h3>
            <p className="text-xs text-stone-500 mt-1 font-semibold uppercase tracking-wider">
              The top choice for local residents, commuters, office workers, and London visitors.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: 'Open 24 Hours',
                desc: 'Never closed. Shop for groceries, food, and essentials at any hour of the day or night.',
                icon: Clock
              },
              {
                title: 'Convenient Central London Location',
                desc: 'Located at 97-99 Westminster Bridge Rd, 3 minutes from London Waterloo station and London Eye.',
                icon: MapPin
              },
              {
                title: 'Wide Range of Products',
                desc: 'Over 1,500 products including fresh produce, dairy, bakery, snacks, drinks, household, and travel items.',
                icon: ShoppingBag
              },
              {
                title: 'Fresh Daily Produce',
                desc: 'Daily deliveries of fresh English fruits, vegetables, eggs, milk, and freshly baked pastries.',
                icon: Sparkles
              },
              {
                title: 'Friendly Customer Service',
                desc: 'Welcoming, helpful team members ready to assist with key cutting, currency exchange, and store requests.',
                icon: HeartHandshake
              },
              {
                title: 'One-Stop Everyday Shop',
                desc: 'Groceries, off-licence, currency exchange, duplicate keys, travel chargers & London souvenirs under one roof.',
                icon: ShieldCheck
              }
            ].map((feature, idx) => {
              const Icon = feature.icon;
              return (
                <div key={idx} className="bg-white p-5 rounded-xl border border-stone-200 shadow-xs">
                  <div className="w-9 h-9 rounded-xl bg-[#2D5A27]/10 text-[#2D5A27] flex items-center justify-center font-bold mb-3 border border-[#2D5A27]/20">
                    <Icon className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-bold text-stone-900 mb-1">{feature.title}</h4>
                  <p className="text-xs text-stone-500 leading-relaxed">{feature.desc}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Real Customer Reviews Section */}
        <div>
          <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-widest text-[#2D5A27] bg-[#2D5A27]/10 px-3 py-1 rounded-full border border-[#2D5A27]/20">
                Customer Testimonials
              </span>
              <h3 className="text-2xl sm:text-3xl font-serif text-stone-800 mt-2">
                ⭐ Rated 4.4/5 from 291 Google Reviews
              </h3>
              <p className="text-xs text-stone-500 mt-1">
                Here is what our shoppers, local neighbors, and London tourists have to say.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {REVIEWS.map((rev) => (
              <div key={rev.id} className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs flex flex-col justify-between hover:border-[#2D5A27] transition-all">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-1 text-amber-500 text-xs">
                      {[...Array(rev.rating)].map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                      ))}
                    </div>
                    <span className="text-[10px] bg-[#2D5A27]/10 text-[#2D5A27] font-bold px-2.5 py-0.5 rounded-full border border-[#2D5A27]/20">
                      {rev.tag || 'Verified'}
                    </span>
                  </div>

                  <p className="text-xs text-stone-700 italic leading-relaxed mb-4">
                    "{rev.comment}"
                  </p>
                </div>

                <div className="pt-3 border-t border-stone-100 flex items-center gap-3">
                  <img src={rev.avatar} alt={rev.author} className="w-8 h-8 rounded-full object-cover border border-stone-200" />
                  <div>
                    <p className="text-xs font-bold text-stone-900">{rev.author}</p>
                    <p className="text-[10px] text-stone-400">{rev.source} • {rev.date}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
