import React, { useState } from 'react';
import { SERVICES, STORE_DETAILS } from '../data/storeInfo';
import { CurrencyCalculator } from './CurrencyCalculator';
import { KeyCuttingWidget } from './KeyCuttingWidget';
import { 
  Clock, 
  Key, 
  Coins, 
  CreditCard, 
  Wine, 
  Compass, 
  CheckCircle2, 
  Sparkles,
  PhoneCall
} from 'lucide-react';

export const ServicesSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'all' | 'currency' | 'key'>('all');

  return (
    <section id="services-section" className="py-12 md:py-16 bg-stone-900 text-white border-b border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <span className="inline-block bg-[#2D5A27]/30 text-emerald-300 border border-[#2D5A27]/50 text-xs font-bold uppercase tracking-widest px-3.5 py-1 rounded-full mb-3">
            In-Store 24/7 Convenience Services
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif text-stone-100 tracking-tight">
            More Than Just A Supermarket
          </h2>
          <p className="text-stone-300 text-sm sm:text-base mt-3 leading-relaxed">
            Waterloo Supermarket is your 24-hour one-stop convenience hub in Central London. From fresh food and travel chargers to currency exchange and instant duplicate keys.
          </p>

          {/* Quick Tabs */}
          <div className="flex justify-center gap-2.5 mt-6">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'all'
                  ? 'bg-[#2D5A27] text-white shadow-xs'
                  : 'bg-stone-800 text-stone-300 hover:bg-stone-700'
              }`}
            >
              All 6 Services
            </button>
            <button
              onClick={() => setActiveTab('currency')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'currency'
                  ? 'bg-amber-500 text-stone-950 shadow-xs'
                  : 'bg-stone-800 text-stone-300 hover:bg-stone-700'
              }`}
            >
              Currency Calculator
            </button>
            <button
              onClick={() => setActiveTab('key')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'key'
                  ? 'bg-[#2D5A27] text-white shadow-xs'
                  : 'bg-stone-800 text-stone-300 hover:bg-stone-700'
              }`}
            >
              Key Cutting Tool
            </button>
          </div>
        </div>

        {/* Interactive Tool Highlights */}
        {(activeTab === 'currency' || activeTab === 'all') && (
          <div className="mb-10">
            <CurrencyCalculator />
          </div>
        )}

        {(activeTab === 'key' || activeTab === 'all') && (
          <div className="mb-10">
            <KeyCuttingWidget />
          </div>
        )}

        {/* Services Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {SERVICES.map((srv) => (
            <div
              key={srv.id}
              className="bg-stone-800/80 rounded-2xl p-6 border border-stone-700 hover:border-[#2D5A27] transition-all shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 rounded-full bg-[#2D5A27]/20 text-emerald-400 border border-[#2D5A27]/40 flex items-center justify-center font-bold">
                    {srv.id.includes('247') && <Clock className="w-5 h-5 text-emerald-400" />}
                    {srv.id.includes('key') && <Key className="w-5 h-5 text-emerald-400" />}
                    {srv.id.includes('currency') && <Coins className="w-5 h-5 text-emerald-400" />}
                    {srv.id.includes('payments') && <CreditCard className="w-5 h-5 text-emerald-400" />}
                    {srv.id.includes('offlicence') && <Wine className="w-5 h-5 text-emerald-400" />}
                    {srv.id.includes('souvenirs') && <Compass className="w-5 h-5 text-emerald-400" />}
                  </div>

                  {srv.badge && (
                    <span className="bg-amber-400/20 text-amber-300 text-[10px] font-extrabold px-2.5 py-0.5 rounded-full border border-amber-400/30">
                      {srv.badge}
                    </span>
                  )}
                </div>

                <h3 className="text-lg font-bold text-white mb-2">{srv.title}</h3>
                <p className="text-xs text-stone-300 mb-4 leading-relaxed">{srv.description}</p>

                <ul className="space-y-2 text-xs text-stone-300">
                  {srv.details.map((dt, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{dt}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-4 border-t border-stone-700 mt-6 text-[11px] text-stone-400 flex items-center justify-between">
                <span>Location: 97–99 Westminster Bridge Rd</span>
                <span className="text-emerald-400 font-bold">Available 24/7</span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
