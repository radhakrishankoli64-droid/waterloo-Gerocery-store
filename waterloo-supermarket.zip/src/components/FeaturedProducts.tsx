import React, { useState } from 'react';
import { Product } from '../types';
import { 
  ShoppingBag, 
  Eye, 
  Star, 
  Check, 
  Filter, 
  Sparkles, 
  Flame, 
  Tag, 
  Clock,
  Plus
} from 'lucide-react';

interface FeaturedProductsProps {
  products: Product[];
  onAddToCart: (product: Product) => void;
  onQuickView: (product: Product) => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  cartProductIds: Record<string, number>;
}

export const FeaturedProducts: React.FC<FeaturedProductsProps> = ({
  products,
  onAddToCart,
  onQuickView,
  selectedCategory,
  setSelectedCategory,
  cartProductIds
}) => {
  const [activeFilter, setActiveFilter] = useState<'all' | 'fresh' | 'offers' | 'popular'>('all');
  const [sortOption, setSortOption] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating'>('featured');
  const [dietaryFilter, setDietaryFilter] = useState<string>('all');

  const categoriesList = [
    'All',
    'Fresh Produce',
    'Dairy & Bakery',
    'Drinks & Beverages',
    'Frozen Food',
    'Snacks & Confectionery',
    'Household & Cleaning',
    'Personal Care',
    'Travel Essentials',
    'London Souvenirs'
  ];

  // Filter products based on selected tab, category, dietary, sort
  let filtered = products.filter(p => {
    // Category match
    if (selectedCategory !== 'All' && selectedCategory !== 'all') {
      if (!p.category.toLowerCase().includes(selectedCategory.toLowerCase()) && 
          !selectedCategory.toLowerCase().includes(p.category.toLowerCase())) {
        return false;
      }
    }

    // Top filter tab
    if (activeFilter === 'fresh' && !p.isFresh) return false;
    if (activeFilter === 'offers' && !p.isOffer) return false;
    if (activeFilter === 'popular' && !p.isPopular) return false;

    // Dietary filter
    if (dietaryFilter !== 'all') {
      if (!p.dietary || !p.dietary.includes(dietaryFilter)) return false;
    }

    return true;
  });

  // Sort
  if (sortOption === 'price-asc') {
    filtered = [...filtered].sort((a, b) => a.price - b.price);
  } else if (sortOption === 'price-desc') {
    filtered = [...filtered].sort((a, b) => b.price - a.price);
  } else if (sortOption === 'rating') {
    filtered = [...filtered].sort((a, b) => b.rating - a.rating);
  }

  return (
    <section id="shop-section" className="py-12 md:py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4 border-b border-stone-200 pb-6">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-2 h-2 rounded-full bg-[#2D5A27]"></span>
              <span className="text-[#2D5A27] font-bold text-xs uppercase tracking-widest">
                Waterloo Supermarket Catalog
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-serif text-stone-800 tracking-tight">
              {selectedCategory === 'All' ? 'In-Stock Groceries & Essentials' : selectedCategory}
            </h2>
            <p className="text-stone-500 text-sm mt-1">
              Showing {filtered.length} products • Open 24/7 for In-Store Shopping & Express Delivery
            </p>
          </div>

          {/* Quick Filters */}
          <div className="flex flex-wrap items-center gap-2">
            {[
              { id: 'all', label: 'All Items' },
              { id: 'fresh', label: 'Fresh Produce', icon: Sparkles },
              { id: 'offers', label: 'Special Deals', icon: Tag },
              { id: 'popular', label: 'Popular Essentials', icon: Flame }
            ].map((filter) => {
              const Icon = filter.icon;
              return (
                <button
                  key={filter.id}
                  onClick={() => setActiveFilter(filter.id as any)}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 ${
                    activeFilter === filter.id
                      ? 'bg-stone-900 text-white shadow-xs'
                      : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                  }`}
                >
                  {Icon && <Icon className="w-3.5 h-3.5" />}
                  <span>{filter.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Category Scroll Bar & Sorting */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 mb-8 bg-[#F8F7F3] p-3 rounded-2xl border border-stone-200">
          
          {/* Category Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0 scrollbar-none flex-1">
            {categoriesList.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-colors ${
                  selectedCategory === cat
                    ? 'bg-[#2D5A27] text-white'
                    : 'bg-white text-stone-700 hover:bg-stone-200 border border-stone-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Sort Selector */}
          <div className="flex items-center gap-2 shrink-0 border-t sm:border-t-0 pt-2 sm:pt-0 border-stone-200">
            <Filter className="w-4 h-4 text-stone-500" />
            <select
              value={sortOption}
              onChange={(e) => setSortOption(e.target.value as any)}
              className="bg-white border border-stone-300 text-stone-800 text-xs font-bold rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-[#2D5A27]"
            >
              <option value="featured">Featured / Default</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="rating">Top Rated ⭐</option>
            </select>
          </div>
        </div>

        {/* Empty state */}
        {filtered.length === 0 && (
          <div className="text-center py-16 bg-[#F8F7F3] rounded-2xl border border-dashed border-stone-300">
            <ShoppingBag className="w-12 h-12 text-stone-300 mx-auto mb-3" />
            <h3 className="text-base font-bold text-stone-800">No matching products found</h3>
            <p className="text-xs text-stone-500 mt-1 max-w-md mx-auto">
              Try resetting your category or filter options. We have over 1,500 items available in-store at 97-99 Westminster Bridge Rd!
            </p>
            <button
              onClick={() => {
                setSelectedCategory('All');
                setActiveFilter('all');
                setDietaryFilter('all');
              }}
              className="mt-4 px-4 py-2 bg-[#2D5A27] text-white text-xs font-bold rounded-lg hover:bg-[#23471f]"
            >
              Reset Filters
            </button>
          </div>
        )}

        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {filtered.map((product) => {
            const quantityInCart = cartProductIds[product.id] || 0;

            return (
              <div
                key={product.id}
                className="group bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs hover:shadow-md hover:border-[#2D5A27] transition-all duration-200 flex flex-col justify-between"
              >
                <div>
                  {/* Image Container */}
                  <div className="relative h-48 w-full bg-stone-100 overflow-hidden">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />

                    {/* Top Badges */}
                    <div className="absolute top-2.5 left-2.5 flex flex-col gap-1 z-10">
                      {product.isOffer && (
                        <span className="bg-rose-700 text-white text-[10px] font-extrabold px-2.5 py-0.5 rounded-md shadow-xs uppercase tracking-wide">
                          {product.offerBadge || 'Deal'}
                        </span>
                      )}
                      {product.isFresh && (
                        <span className="bg-[#2D5A27] text-white text-[10px] font-bold px-2.5 py-0.5 rounded-md shadow-xs">
                          🌱 Fresh Daily
                        </span>
                      )}
                      {product.isPopular && !product.isOffer && (
                        <span className="bg-amber-600 text-white text-[10px] font-bold px-2.5 py-0.5 rounded-md shadow-xs">
                          🔥 Popular
                        </span>
                      )}
                    </div>

                    {/* Quick View Button */}
                    <button
                      onClick={() => onQuickView(product)}
                      className="absolute top-2.5 right-2.5 bg-white/90 hover:bg-white text-stone-700 hover:text-[#2D5A27] p-2 rounded-xl shadow-xs opacity-0 group-hover:opacity-100 transition-opacity duration-200 border border-stone-200"
                      title="Quick View Details"
                    >
                      <Eye className="w-4 h-4" />
                    </button>

                    <div className="absolute bottom-2 left-2 bg-stone-900/80 text-white text-[10px] font-bold px-2 py-0.5 rounded">
                      {product.unit}
                    </div>
                  </div>

                  {/* Product Details */}
                  <div className="p-4">
                    <div className="flex items-center justify-between text-[11px] text-stone-500 mb-1">
                      <span className="font-bold text-[#2D5A27] uppercase tracking-wider">{product.category}</span>
                      <span className="flex items-center gap-1 font-bold text-amber-700">
                        ⭐ {product.rating} <span className="text-stone-400 font-normal">({product.reviewsCount})</span>
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-stone-900 line-clamp-2 hover:text-[#2D5A27] transition-colors leading-snug">
                      {product.name}
                    </h3>

                    {/* Dietary Tags */}
                    {product.dietary && product.dietary.length > 0 && (
                      <div className="flex flex-wrap gap-1 my-2">
                        {product.dietary.slice(0, 2).map(tag => (
                          <span key={tag} className="text-[10px] bg-[#F8F7F3] text-stone-600 font-bold px-2 py-0.5 rounded border border-stone-200">
                            {tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Footer Price & Add To Cart */}
                <div className="p-4 pt-0 border-t border-stone-100 mt-2">
                  <div className="flex items-baseline gap-2 my-2">
                    <span className="text-lg font-extrabold text-stone-900 font-mono">
                      £{product.price.toFixed(2)}
                    </span>
                    {product.originalPrice && (
                      <span className="text-xs text-stone-400 line-through font-mono">
                        £{product.originalPrice.toFixed(2)}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onAddToCart(product)}
                      className={`flex-1 py-2.5 px-3 rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs ${
                        quantityInCart > 0
                          ? 'bg-[#2D5A27] text-white hover:bg-[#23471f]'
                          : 'bg-stone-900 text-white hover:bg-stone-800'
                      }`}
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>{quantityInCart > 0 ? `Added (${quantityInCart})` : 'Add to Cart'}</span>
                    </button>

                    <button
                      onClick={() => onQuickView(product)}
                      className="p-2 border border-stone-200 hover:border-stone-300 rounded-lg text-stone-600 hover:text-stone-900 transition-colors"
                      title="View product details"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  </div>
                </div>

              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
