import React from 'react';
import { STORE_DETAILS, NEARBY_LANDMARKS } from '../data/storeInfo';
import { 
  MapPin, 
  Phone, 
  Clock, 
  Navigation, 
  Train, 
  Landmark, 
  CheckCircle2, 
  Star,
  ExternalLink,
  Users
} from 'lucide-react';

export const LocationSection: React.FC = () => {
  return (
    <section id="location-section" className="py-12 md:py-16 bg-[#F8F7F3] border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Store Info */}
          <div className="lg:col-span-5 space-y-6">
            <div>
              <span className="inline-block bg-[#2D5A27]/10 text-[#2D5A27] text-xs font-bold uppercase tracking-widest px-3.5 py-1 rounded-full border border-[#2D5A27]/20 mb-3">
                Central London Location
              </span>
              <h2 className="text-2xl sm:text-3xl md:text-4xl font-serif text-stone-800 tracking-tight">
                Visit Waterloo Supermarket
              </h2>
              <p className="text-stone-600 text-sm sm:text-base mt-2">
                Located right on Westminster Bridge Road, steps from London Waterloo station and world-renowned South Bank landmarks.
              </p>
            </div>

            {/* Address Card */}
            <div className="bg-white rounded-2xl p-6 border border-stone-200 shadow-xs space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-[#2D5A27]/10 text-[#2D5A27] flex items-center justify-center shrink-0 font-bold border border-[#2D5A27]/20">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-stone-400 uppercase tracking-widest">Store Address</h3>
                  <p className="text-sm font-bold text-stone-900 mt-0.5">{STORE_DETAILS.address}</p>
                  <p className="text-xs text-stone-500 mt-0.5">Postcode: {STORE_DETAILS.postcode}</p>
                </div>
              </div>

              <div className="flex items-start gap-3 pt-3 border-t border-stone-100">
                <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0 font-bold border border-amber-200">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-stone-400 uppercase tracking-widest">Opening Hours</h3>
                  <p className="text-sm font-bold text-[#2D5A27] mt-0.5 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-[#2D5A27] animate-pulse"></span>
                    {STORE_DETAILS.openingHours}
                  </p>
                  <p className="text-xs text-stone-500">Open Monday to Sunday, 365 days a year</p>
                </div>
              </div>

              <div className="flex items-start gap-3 pt-3 border-t border-stone-100">
                <div className="w-9 h-9 rounded-xl bg-stone-100 text-stone-800 flex items-center justify-center shrink-0 font-bold border border-stone-200">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-stone-400 uppercase tracking-widest">Phone Contact</h3>
                  <a href={`tel:${STORE_DETAILS.phone}`} className="text-sm font-bold text-stone-900 hover:text-[#2D5A27] transition-colors mt-0.5 block">
                    {STORE_DETAILS.phoneFormatted} ({STORE_DETAILS.phone})
                  </a>
                </div>
              </div>

              {/* Get Directions Button */}
              <div className="pt-2">
                <a
                  href="https://maps.google.com/?q=97-99+Westminster+Bridge+Road+London+SE1+7HR"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full bg-stone-900 hover:bg-stone-800 text-white font-bold py-3 rounded-lg text-xs flex items-center justify-center gap-2 shadow-xs transition-all"
                >
                  <Navigation className="w-4 h-4 text-emerald-400" />
                  <span>Get Google Maps Walking Directions</span>
                  <ExternalLink className="w-3.5 h-3.5 text-stone-400" />
                </a>
              </div>
            </div>

            {/* Target Customers Served */}
            <div className="bg-[#2D5A27] text-white rounded-2xl p-6 shadow-xs space-y-2">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-emerald-200" />
                <h3 className="text-sm font-bold">Serving Everyone in Waterloo</h3>
              </div>
              <p className="text-xs text-emerald-100 leading-relaxed">
                Whether you are a local resident, busy office worker, daily commuter at Waterloo station, university student, family, or international tourist visiting Big Ben — our doors are always open for you.
              </p>
            </div>

          </div>

          {/* Right Map & Nearby Landmarks */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Visual London Map Container */}
            <div className="bg-white rounded-2xl p-4 border border-stone-200 shadow-xs overflow-hidden">
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-stone-100">
                <span className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-[#2D5A27]" />
                  Central London Location Map
                </span>
                <span className="text-[11px] bg-[#2D5A27]/10 text-[#2D5A27] font-bold px-2.5 py-0.5 rounded-full border border-[#2D5A27]/20">
                  SE1 7HR • Waterloo
                </span>
              </div>

              {/* Embedded Custom Map Canvas Graphic */}
              <div className="relative h-64 sm:h-72 w-full rounded-xl overflow-hidden bg-stone-100 border border-stone-200">
                <img
                  src="https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?auto=format&fit=crop&w=1000&q=80"
                  alt="London Waterloo Map area"
                  className="w-full h-full object-cover filter contrast-105"
                />
                <div className="absolute inset-0 bg-stone-950/40" />

                {/* Pin Point Marker */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white text-stone-900 p-3 rounded-2xl shadow-lg border-2 border-[#2D5A27] flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-[#2D5A27] text-white flex items-center justify-center font-black">
                    W
                  </div>
                  <div className="text-left pr-1">
                    <p className="text-xs font-extrabold text-stone-900">Waterloo Supermarket</p>
                    <p className="text-[10px] text-[#2D5A27] font-bold">97-99 Westminster Bridge Rd</p>
                  </div>
                </div>

                <div className="absolute bottom-3 left-3 bg-stone-900/90 text-white text-[11px] p-3 rounded-xl border border-stone-700 space-y-0.5">
                  <p className="font-bold text-emerald-400">🚶 Distance to Landmarks:</p>
                  <p className="text-stone-200">Waterloo Station: 250m (3m walk)</p>
                  <p className="text-stone-200">London Eye: 450m (5m walk)</p>
                </div>
              </div>
            </div>

            {/* Nearby Attraction Cards */}
            <div>
              <h3 className="text-xs font-bold text-stone-900 uppercase tracking-widest mb-3">
                Nearby Attractions & Distance
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {NEARBY_LANDMARKS.map((lm, idx) => (
                  <div key={idx} className="bg-white p-3.5 rounded-xl border border-stone-200 hover:border-[#2D5A27] transition-colors shadow-xs">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold text-stone-900">{lm.name}</h4>
                      <span className="text-[10px] bg-amber-100 text-amber-900 font-bold px-2 py-0.5 rounded border border-amber-200">
                        {lm.walkTime}
                      </span>
                    </div>
                    <p className="text-[11px] text-stone-500 mt-1">{lm.description}</p>
                    <p className="text-[10px] text-[#2D5A27] font-bold mt-1">📍 {lm.distance}</p>
                  </div>
                ))}
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
