import React from 'react';
import { STORE_DETAILS } from '../data/storeInfo';
import { MapPin, Phone, Mail, Clock, Heart, ShieldCheck, Coins, Key } from 'lucide-react';

interface FooterProps {
  onNavigateTab: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigateTab }) => {
  return (
    <footer className="bg-stone-950 text-stone-400 border-t border-stone-800 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-12">
          
          {/* Col 1: Store Branding & About */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#2D5A27] text-white font-serif font-extrabold text-xl flex items-center justify-center shadow-xs">
                W
              </div>
              <div>
                <span className="font-serif font-bold text-lg text-white tracking-tight">WATERLOO SUPERMARKET</span>
                <p className="text-[10px] text-amber-300 font-bold uppercase tracking-widest">
                  24-Hour Convenience & Groceries
                </p>
              </div>
            </div>

            <p className="text-stone-400 text-xs leading-relaxed max-w-md">
              Waterloo Supermarket is a 24-hour convenience store located in Central London on Westminster Bridge Road. Serving local residents, commuters, students, and tourists with fresh produce, household essentials, key cutting, and currency exchange.
            </p>

            <div className="flex items-center gap-2 text-emerald-400 font-bold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>Open 24 Hours • 7 Days a Week</span>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div className="space-y-3">
            <h4 className="font-bold text-white uppercase text-[11px] tracking-widest">Website Links</h4>
            <ul className="space-y-2">
              {[
                { id: 'home', label: 'Home Page' },
                { id: 'shop', label: 'Shop Catalog' },
                { id: 'categories', label: 'Aisle Categories' },
                { id: 'offers', label: 'Special Offers & Bundles' },
                { id: 'services', label: '24/7 Services' },
                { id: 'about', label: 'About Waterloo Store' },
                { id: 'contact', label: 'Contact & Store Map' }
              ].map((link) => (
                <li key={link.id}>
                  <button
                    onClick={() => onNavigateTab(link.id)}
                    className="hover:text-emerald-400 transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Services */}
          <div className="space-y-3">
            <h4 className="font-bold text-white uppercase text-[11px] tracking-widest">Services</h4>
            <ul className="space-y-2 text-stone-400">
              <li>24/7 Grocery Shopping</li>
              <li>SE1 30-Min Local Express Delivery</li>
              <li>Zero-Commission Bureau de Change</li>
              <li>Instant Key Cutting Service</li>
              <li>London Souvenir & Travel Corner</li>
              <li>Licensed Off-Licence (24/7)</li>
            </ul>
          </div>

          {/* Col 4: Store Contact */}
          <div className="space-y-3">
            <h4 className="font-bold text-white uppercase text-[11px] tracking-widest">Store Location</h4>
            <div className="space-y-2 text-stone-300">
              <p className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>{STORE_DETAILS.address}</span>
              </p>
              <p className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
                <a href={`tel:${STORE_DETAILS.phone}`} className="hover:text-emerald-400 font-mono font-bold">
                  {STORE_DETAILS.phoneFormatted}
                </a>
              </p>
              <p className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Open 24 Hours (Mon–Sun)</span>
              </p>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-stone-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-stone-500">
          <p>© {new Date().getFullYear()} Waterloo Supermarket. All rights reserved. 97–99 Westminster Bridge Road, London SE1 7HR.</p>
          <div className="flex items-center gap-3">
            <span className="bg-stone-900 px-2.5 py-1 rounded border border-stone-800 text-stone-300 font-mono">
              Accepted: Visa • Mastercard • AMEX • Apple Pay • Contactless
            </span>
          </div>
        </div>

      </div>
    </footer>
  );
};
