import React, { useState } from 'react';
import { Product } from '../types';
import { X, ShoppingBag, Star, Check, Sparkles, Clock, ShieldCheck, Plus, Minus } from 'lucide-react';

interface ProductQuickViewProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number) => void;
}

export const ProductQuickView: React.FC<ProductQuickViewProps> = ({
  product,
  onClose,
  onAddToCart
}) => {
  const [quantity, setQuantity] = useState(1);

  if (!product) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-stone-200 overflow-hidden animate-in zoom-in-95 duration-200 relative my-8">
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 bg-white/90 hover:bg-white text-stone-700 p-2 rounded-full shadow-md transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          
          {/* Image Left */}
          <div className="relative h-64 md:h-full bg-stone-100 min-h-[260px]">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
            />
            {product.isOffer && (
              <span className="absolute top-3 left-3 bg-stone-900 text-white text-xs font-bold px-2.5 py-1 rounded-md shadow-md uppercase tracking-wider">
                {product.offerBadge || 'Special Offer'}
              </span>
            )}
            {product.isFresh && (
              <span className="absolute top-3 right-3 bg-[#2D5A27] text-white text-xs font-bold px-2.5 py-1 rounded-md shadow-md">
                Fresh Daily
              </span>
            )}
          </div>

          {/* Details Right */}
          <div className="p-6 flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center justify-between text-xs text-stone-500 mb-1">
                <span className="font-bold text-[#2D5A27] uppercase tracking-widest">{product.category}</span>
                <span className="flex items-center gap-1 font-bold text-amber-600">
                  ⭐ {product.rating} ({product.reviewsCount} reviews)
                </span>
              </div>

              <h3 className="text-xl sm:text-2xl font-serif text-stone-900 leading-snug">
                {product.name}
              </h3>

              <p className="text-xs text-stone-500 font-medium mt-1">
                Unit / Size: <span className="text-stone-800 font-semibold">{product.unit}</span>
              </p>

              <p className="text-xs text-stone-600 mt-3 leading-relaxed">
                {product.description}
              </p>

              {/* Dietary / Feature Tags */}
              {product.dietary && product.dietary.length > 0 && (
                <div className="mt-4 pt-3 border-t border-stone-100">
                  <span className="text-[10px] font-bold text-stone-400 uppercase tracking-widest block mb-1.5">
                    Dietary & Product Highlights
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {product.dietary.map(d => (
                      <span key={d} className="bg-[#2D5A27]/10 text-[#2D5A27] text-[11px] font-semibold px-2.5 py-0.5 rounded-full border border-[#2D5A27]/20">
                        ✓ {d}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Stock Status */}
              <div className="mt-3 text-xs flex items-center gap-1.5 text-[#2D5A27] font-bold">
                <Check className="w-4 h-4 text-[#2D5A27]" />
                <span>In Stock at 97–99 Westminster Bridge Rd (Available 24/7)</span>
              </div>
            </div>

            {/* Price & Quantity Add */}
            <div className="pt-4 border-t border-stone-100 space-y-3">
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-bold text-stone-900 font-mono">
                  £{(product.price * quantity).toFixed(2)}
                </span>
                {product.originalPrice && (
                  <span className="text-xs text-stone-400 line-through font-mono">
                    £{(product.originalPrice * quantity).toFixed(2)}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center border border-stone-300 rounded-lg overflow-hidden bg-stone-50">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="p-2.5 text-stone-600 hover:text-stone-900 hover:bg-stone-200 transition-colors"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span className="w-8 text-center text-xs font-bold text-stone-900">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="p-2.5 text-stone-600 hover:text-stone-900 hover:bg-stone-200 transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>

                <button
                  onClick={() => {
                    onAddToCart(product, quantity);
                    onClose();
                  }}
                  className="flex-1 bg-[#2D5A27] hover:bg-[#23471f] text-white font-bold py-3 rounded-lg text-xs flex items-center justify-center gap-2 shadow-xs transition-all"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Add To Cart</span>
                </button>
              </div>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
