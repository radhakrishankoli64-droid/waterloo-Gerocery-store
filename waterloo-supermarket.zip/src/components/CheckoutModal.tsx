import React, { useState } from 'react';
import { CartItem } from '../types';
import { STORE_DETAILS } from '../data/storeInfo';
import { 
  X, 
  CheckCircle2, 
  Clock, 
  MapPin, 
  CreditCard, 
  Truck, 
  ShoppingBag, 
  Phone, 
  ShieldCheck, 
  ArrowRight,
  Printer
} from 'lucide-react';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  fulfillmentType: 'delivery' | 'pickup';
  promoDiscount: number;
  onOrderCompleted: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  cart,
  fulfillmentType,
  promoDiscount,
  onOrderCompleted
}) => {
  const [step, setStep] = useState<'form' | 'tracking'>('form');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'applepay' | 'cash'>('card');
  const [formData, setFormData] = useState({
    name: 'Sarah Jenkins',
    phone: '+44 7911 123456',
    address: 'Park Plaza Westminster Bridge Hotel, 200 Westminster Bridge Rd',
    postcode: 'SE1 7UT',
    instructions: 'Leave at front reception desk or call on arrival.'
  });

  const [orderTrackingStage, setOrderTrackingStage] = useState<number>(1); // 1, 2, 3

  if (!isOpen) return null;

  const rawSubtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const discountAmount = (rawSubtotal * promoDiscount) / 100;
  const subtotalAfterDiscount = rawSubtotal - discountAmount;
  const isFreeDelivery = subtotalAfterDiscount >= STORE_DETAILS.freeDeliveryThreshold;
  const deliveryFee = fulfillmentType === 'delivery' ? (isFreeDelivery ? 0 : STORE_DETAILS.deliveryFee) : 0;
  const grandTotal = subtotalAfterDiscount + deliveryFee;

  const orderId = `WS-${Math.floor(100000 + Math.random() * 900000)}`;

  const handleConfirmOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('tracking');
    
    // Simulate live order tracking progress
    setTimeout(() => setOrderTrackingStage(2), 2500);
    setTimeout(() => setOrderTrackingStage(3), 5500);
  };

  const handleFinish = () => {
    onOrderCompleted();
    onClose();
    setStep('form');
    setOrderTrackingStage(1);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-xl w-full shadow-2xl border border-stone-200 overflow-hidden animate-in zoom-in-95 duration-200 my-8">
        
        {/* Header */}
        <div className="bg-stone-900 text-white p-5 flex items-center justify-between border-b border-stone-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#2D5A27] text-white font-serif font-extrabold flex items-center justify-center text-lg">
              W
            </div>
            <div>
              <h3 className="font-serif font-bold text-base">Waterloo Supermarket Checkout</h3>
              <p className="text-xs text-stone-300">
                {fulfillmentType === 'delivery' ? 'Express 30-Min Local SE1 Delivery' : '15-Min In-Store Click & Collect'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-white rounded-lg hover:bg-stone-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {step === 'form' ? (
          <form onSubmit={handleConfirmOrder} className="p-6 space-y-5 text-xs text-stone-800 max-h-[80vh] overflow-y-auto">
            
            {/* Fulfillment info banner */}
            <div className="bg-[#F8F7F3] border border-stone-200 rounded-2xl p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-[#2D5A27] text-white flex items-center justify-center font-bold shrink-0">
                  {fulfillmentType === 'delivery' ? <Truck className="w-4 h-4" /> : <MapPin className="w-4 h-4" />}
                </div>
                <div>
                  <p className="font-bold text-stone-900 text-xs">
                    {fulfillmentType === 'delivery' ? 'Express Hotel / Flat Delivery' : 'Collect from Store Counter'}
                  </p>
                  <p className="text-[11px] text-stone-500">
                    {fulfillmentType === 'delivery' ? 'Dispatching from 97-99 Westminster Bridge Rd' : 'Ready in 15 mins • Open 24 Hours'}
                  </p>
                </div>
              </div>
              <span className="text-xs font-mono font-bold text-[#2D5A27]">
                £{grandTotal.toFixed(2)}
              </span>
            </div>

            {/* Customer Details */}
            <div className="space-y-3">
              <h4 className="font-bold text-stone-900 uppercase tracking-widest text-[11px] text-stone-400">
                1. Customer & Delivery Address
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1 text-stone-700">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-stone-50 border border-stone-300 rounded-lg px-3 py-2 outline-none focus:border-[#2D5A27]"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1 text-stone-700">Mobile Phone (for Courier) *</label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full bg-stone-50 border border-stone-300 rounded-lg px-3 py-2 outline-none focus:border-[#2D5A27]"
                  />
                </div>
              </div>

              {fulfillmentType === 'delivery' && (
                <>
                  <div>
                    <label className="block font-bold mb-1 text-stone-700">London Street Address / Hotel / Office *</label>
                    <input
                      type="text"
                      required
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      className="w-full bg-stone-50 border border-stone-300 rounded-lg px-3 py-2 outline-none focus:border-[#2D5A27]"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-bold mb-1 text-stone-700">Postcode (Waterloo / SE1) *</label>
                      <input
                        type="text"
                        required
                        value={formData.postcode}
                        onChange={(e) => setFormData({ ...formData, postcode: e.target.value })}
                        className="w-full bg-stone-50 border border-stone-300 rounded-lg px-3 py-2 outline-none focus:border-[#2D5A27]"
                      />
                    </div>

                    <div>
                      <label className="block font-bold mb-1 text-stone-700">Delivery Notes</label>
                      <input
                        type="text"
                        value={formData.instructions}
                        onChange={(e) => setFormData({ ...formData, instructions: e.target.value })}
                        className="w-full bg-stone-50 border border-stone-300 rounded-lg px-3 py-2 outline-none focus:border-[#2D5A27]"
                      />
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Payment Method */}
            <div className="space-y-3 pt-2 border-t border-stone-100">
              <h4 className="font-bold uppercase tracking-widest text-[11px] text-stone-400">
                2. Select Payment Method
              </h4>

              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'card', label: 'Card Payment', sub: 'Visa / AMEX' },
                  { id: 'applepay', label: 'Apple / Google Pay', sub: 'Contactless' },
                  { id: 'cash', label: fulfillmentType === 'delivery' ? 'Cash on Delivery' : 'Pay at Counter', sub: '24/7 Cash' }
                ].map((pay) => (
                  <button
                    key={pay.id}
                    type="button"
                    onClick={() => setPaymentMethod(pay.id as any)}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      paymentMethod === pay.id
                        ? 'border-[#2D5A27] bg-[#2D5A27]/10 text-[#2D5A27] font-bold shadow-xs'
                        : 'border-stone-200 bg-white text-stone-700 hover:bg-stone-50'
                    }`}
                  >
                    <p className="font-bold">{pay.label}</p>
                    <p className="text-[10px] text-stone-500 mt-0.5">{pay.sub}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Order Summary Breakdown */}
            <div className="bg-[#F8F7F3] rounded-2xl p-4 border border-stone-200 space-y-2 font-mono text-[11px]">
              <div className="flex justify-between text-stone-600">
                <span>Items Subtotal ({cart.length} unique)</span>
                <span>£{rawSubtotal.toFixed(2)}</span>
              </div>
              {promoDiscount > 0 && (
                <div className="flex justify-between text-[#2D5A27] font-bold">
                  <span>Promo Discount ({promoDiscount}%)</span>
                  <span>-£{discountAmount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-stone-600">
                <span>Fulfillment Fee</span>
                <span>{deliveryFee === 0 ? 'FREE' : `£${deliveryFee.toFixed(2)}`}</span>
              </div>
              <div className="flex justify-between text-sm font-bold text-stone-900 pt-2 border-t border-stone-200 font-mono">
                <span>Total Amount Due</span>
                <span className="text-[#2D5A27] font-bold">£{grandTotal.toFixed(2)}</span>
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-[#2D5A27] hover:bg-[#23471f] text-white font-bold py-4 rounded-lg text-sm flex items-center justify-center gap-2 shadow-xs transition-all"
            >
              <ShieldCheck className="w-5 h-5 text-amber-300" />
              <span>Confirm & Pay £{grandTotal.toFixed(2)}</span>
            </button>
          </form>
        ) : (
          /* Live Order Tracking & Confirmation Screen */
          <div className="p-6 space-y-6 text-xs text-stone-800">
            
            <div className="text-center space-y-1">
              <span className="bg-[#2D5A27]/10 text-[#2D5A27] font-bold text-[11px] px-3 py-1 rounded-full uppercase tracking-widest border border-[#2D5A27]/20">
                Order Confirmed #{orderId}
              </span>
              <h3 className="text-xl sm:text-2xl font-serif text-stone-900 mt-2">
                Thank You, {formData.name}!
              </h3>
              <p className="text-stone-500">
                Your order is being processed 24/7 at Waterloo Supermarket (97-99 Westminster Bridge Rd).
              </p>
            </div>

            {/* Live Progress Stage */}
            <div className="bg-stone-900 text-white rounded-2xl p-5 space-y-4 border border-stone-800">
              <h4 className="text-xs font-bold text-amber-300 uppercase tracking-widest flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-300 animate-spin" />
                Live Waterloo Order Tracking Status
              </h4>

              <div className="space-y-3">
                {[
                  { step: 1, title: 'Order Received & Paid', detail: `Order #${orderId} logged into 24/7 system` },
                  { step: 2, title: 'Packing at Westminster Bridge Rd Store', detail: 'Fresh items picked from Waterloo aisles' },
                  { step: 3, title: fulfillmentType === 'delivery' ? 'Out with SE1 Courier' : 'Ready for Counter Pickup', detail: fulfillmentType === 'delivery' ? `En route to ${formData.address}` : 'Collect anytime with your Order ID' }
                ].map((s) => {
                  const isDone = orderTrackingStage >= s.step;
                  const isCurrent = orderTrackingStage === s.step;

                  return (
                    <div key={s.step} className="flex items-start gap-3">
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5 ${
                        isDone ? 'bg-[#2D5A27] text-white' : 'bg-stone-800 text-stone-500'
                      }`}>
                        {isDone ? '✓' : s.step}
                      </div>
                      <div>
                        <p className={`font-bold ${isCurrent ? 'text-amber-300' : isDone ? 'text-emerald-300' : 'text-stone-500'}`}>
                          {s.title}
                        </p>
                        <p className="text-[11px] text-stone-400">{s.detail}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Digital Receipt summary */}
            <div className="bg-[#F8F7F3] rounded-2xl p-4 border border-stone-200 space-y-2">
              <div className="flex justify-between items-center border-b border-stone-200 pb-2 font-bold text-stone-900">
                <span>Receipt Breakdown</span>
                <span className="text-[11px] text-stone-500 font-mono">{orderId}</span>
              </div>
              <div className="space-y-1 font-mono text-[11px] text-stone-600">
                {cart.map(i => (
                  <div key={i.product.id} className="flex justify-between">
                    <span>{i.quantity}x {i.product.name}</span>
                    <span>£{(i.product.price * i.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>
              <div className="pt-2 border-t border-stone-200 flex justify-between font-bold text-stone-900 text-sm font-mono">
                <span>Total Paid</span>
                <span className="text-[#2D5A27]">£{grandTotal.toFixed(2)}</span>
              </div>
            </div>

            <button
              onClick={handleFinish}
              className="w-full bg-stone-900 hover:bg-stone-800 text-white font-bold py-3.5 rounded-lg text-xs flex items-center justify-center gap-2"
            >
              <span>Back to Waterloo Store</span>
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
