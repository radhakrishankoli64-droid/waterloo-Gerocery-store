import React, { useState } from 'react';
import { Key, CheckCircle2, Clock, Shield } from 'lucide-react';

export const KeyCuttingWidget: React.FC = () => {
  const [keyType, setKeyType] = useState('yale');
  const [quantity, setQuantity] = useState(1);
  const [booked, setBooked] = useState(false);
  const [timeSlot, setTimeSlot] = useState('In 15 minutes');

  const prices: Record<string, number> = {
    yale: 5.00,
    mortice: 7.50,
    padlock: 4.50,
    security: 9.00
  };

  const totalPrice = (prices[keyType] * quantity).toFixed(2);

  return (
    <div className="bg-[#F8F7F3] rounded-2xl border border-stone-200 p-6 shadow-xs">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-full bg-[#2D5A27] text-white flex items-center justify-center font-bold shadow-xs">
          <Key className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-lg font-serif text-stone-900">Instant Key Cutting Service</h3>
          <p className="text-xs text-stone-500">Precision Duplicate Keys Made in Under 3 Minutes • 24/7</p>
        </div>
      </div>

      {!booked ? (
        <div className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-stone-700 mb-1">Select Key Profile</label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'yale', label: 'Standard Yale Cylinder Key', price: '£5.00' },
                { id: 'mortice', label: 'Mortice / Chubb Door Key', price: '£7.50' },
                { id: 'padlock', label: 'Padlock & Small Locker Key', price: '£4.50' },
                { id: 'security', label: 'High Security Dimple Key', price: '£9.00' }
              ].map((k) => (
                <button
                  key={k.id}
                  type="button"
                  onClick={() => setKeyType(k.id)}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    keyType === k.id
                      ? 'border-[#2D5A27] bg-[#2D5A27]/10 text-[#2D5A27] font-bold shadow-xs'
                      : 'border-stone-200 bg-white text-stone-700 hover:bg-stone-50'
                  }`}
                >
                  <p className="text-xs font-semibold">{k.label}</p>
                  <p className="text-[11px] font-mono text-[#2D5A27] mt-0.5">{k.price} each</p>
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-stone-700 mb-1">Number of Copies</label>
              <div className="flex items-center border border-stone-300 rounded-lg overflow-hidden bg-white">
                <button
                  type="button"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3 py-1.5 bg-stone-100 font-bold text-stone-700 hover:bg-stone-200"
                >
                  -
                </button>
                <span className="flex-1 text-center font-bold text-stone-900">{quantity}</span>
                <button
                  type="button"
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-3 py-1.5 bg-stone-100 font-bold text-stone-700 hover:bg-stone-200"
                >
                  +
                </button>
              </div>
            </div>

            <div>
              <label className="block font-bold text-stone-700 mb-1">Pickup Time</label>
              <select
                value={timeSlot}
                onChange={(e) => setTimeSlot(e.target.value)}
                className="w-full bg-white border border-stone-300 rounded-lg px-2.5 py-2 font-semibold text-stone-800 focus:outline-none focus:border-[#2D5A27]"
              >
                <option value="In 15 minutes">In 15 minutes (Walk-in)</option>
                <option value="In 1 hour">In 1 Hour</option>
                <option value="Later Today">Later Today (24/7)</option>
              </select>
            </div>
          </div>

          <div className="bg-stone-900 text-white rounded-xl p-3 flex items-center justify-between border border-stone-800">
            <div>
              <span className="text-[10px] text-stone-400 block uppercase">Total Estimated Price</span>
              <span className="text-xl font-bold text-amber-300 font-mono">£{totalPrice}</span>
            </div>
            <span className="text-[10px] bg-[#2D5A27] text-white px-2 py-1 rounded font-semibold">
              Guaranteed Fit
            </span>
          </div>

          <button
            type="button"
            onClick={() => setBooked(true)}
            className="w-full bg-[#2D5A27] hover:bg-[#23471f] text-white font-bold py-2.5 rounded-lg transition-all shadow-xs flex items-center justify-center gap-2"
          >
            <Key className="w-4 h-4" />
            <span>Book Express Key Cutting Slot</span>
          </button>
        </div>
      ) : (
        <div className="bg-[#2D5A27]/10 border border-[#2D5A27]/20 rounded-xl p-4 text-[#2D5A27] text-xs space-y-2">
          <div className="flex items-center gap-2 font-bold text-sm text-[#2D5A27]">
            <CheckCircle2 className="w-5 h-5 text-[#2D5A27] shrink-0" />
            <span>Key Slot Reserved!</span>
          </div>
          <p>
            Your slot for <strong className="font-semibold">{quantity}x {keyType.toUpperCase()}</strong> duplicates (£{totalPrice}) is ready.
          </p>
          <div className="bg-white p-2.5 rounded-lg border border-stone-200 text-[11px] font-mono text-stone-700 space-y-1">
            <p>📍 Bring key to: 97-99 Westminster Bridge Rd, London SE1 7HR</p>
            <p>⏰ Slot: {timeSlot}</p>
            <p>⚡ Cut in 3 minutes while you wait or shop groceries</p>
          </div>
          <button
            onClick={() => setBooked(false)}
            className="text-xs font-bold text-[#2D5A27] underline pt-1"
          >
            Book another key
          </button>
        </div>
      )}
    </div>
  );
};
