import React, { useState } from 'react';
import { CURRENCY_RATES, STORE_DETAILS } from '../data/storeInfo';
import { Coins, ArrowRightLeft, CheckCircle2, Clock, MapPin, Phone } from 'lucide-react';

export const CurrencyCalculator: React.FC = () => {
  const [selectedCurrency, setSelectedCurrency] = useState('USD');
  const [foreignAmount, setForeignAmount] = useState<number>(100);
  const [reservationSuccess, setReservationSuccess] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');

  const currentRate = CURRENCY_RATES.find(c => c.code === selectedCurrency) || CURRENCY_RATES[0];
  const calculatedGbp = (foreignAmount / currentRate.buyRate).toFixed(2);

  const handleReserve = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerPhone) return;
    setReservationSuccess(true);
  };

  return (
    <div className="bg-[#F8F7F3] rounded-2xl border border-stone-200 p-6 shadow-xs">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-full bg-[#2D5A27] text-white flex items-center justify-center font-bold shadow-xs">
          <Coins className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-lg font-serif text-stone-900">Zero-Commission Bureau de Change</h3>
          <p className="text-xs text-stone-500">24/7 In-Store Currency Exchange • 97-99 Westminster Bridge Rd</p>
        </div>
      </div>

      {!reservationSuccess ? (
        <form onSubmit={handleReserve} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            
            {/* Currency Select */}
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">Select Currency</label>
              <select
                value={selectedCurrency}
                onChange={(e) => setSelectedCurrency(e.target.value)}
                className="w-full bg-white border border-stone-300 rounded-lg px-3 py-2 text-xs font-semibold text-stone-800 focus:outline-none focus:border-[#2D5A27]"
              >
                {CURRENCY_RATES.map((c) => (
                  <option key={c.code} value={c.code}>
                    {c.flag} {c.code} – {c.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Foreign Amount */}
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                You Give ({selectedCurrency})
              </label>
              <input
                type="number"
                min="10"
                step="10"
                value={foreignAmount}
                onChange={(e) => setForeignAmount(Math.max(1, Number(e.target.value)))}
                className="w-full bg-white border border-stone-300 rounded-lg px-3 py-2 text-xs font-bold text-stone-900 focus:outline-none focus:border-[#2D5A27]"
              />
            </div>

          </div>

          {/* Exchange Result Display Box */}
          <div className="bg-stone-900 text-white rounded-xl p-4 flex items-center justify-between border border-stone-800">
            <div>
              <span className="text-[10px] text-stone-400 block uppercase font-medium">Estimated GBP Output</span>
              <span className="text-2xl font-bold text-amber-300 font-mono">£{calculatedGbp}</span>
            </div>
            <div className="text-right text-[11px] text-stone-300">
              <span className="block font-medium">Rate: 1 GBP = {currentRate.buyRate} {currentRate.code}</span>
              <span className="text-emerald-400 font-bold">✨ £0 Commission</span>
            </div>
          </div>

          {/* Reserve cash for instant pickup */}
          <div className="pt-2 border-t border-stone-200">
            <p className="text-xs font-bold text-stone-800 mb-2">Pre-Order Cash for 24/7 Pickup</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-3">
              <input
                type="text"
                placeholder="Your Full Name"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                required
                className="bg-white border border-stone-300 rounded-lg px-3 py-1.5 text-xs text-stone-800 outline-none focus:border-[#2D5A27]"
              />
              <input
                type="tel"
                placeholder="Mobile / WhatsApp"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                required
                className="bg-white border border-stone-300 rounded-lg px-3 py-1.5 text-xs text-stone-800 outline-none focus:border-[#2D5A27]"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-[#2D5A27] hover:bg-[#23471f] text-white font-bold py-2.5 rounded-lg text-xs transition-all flex items-center justify-center gap-2 shadow-xs"
            >
              <Coins className="w-4 h-4" />
              <span>Reserve Currency For Express Pickup</span>
            </button>
          </div>
        </form>
      ) : (
        <div className="bg-[#2D5A27]/10 border border-[#2D5A27]/20 rounded-xl p-4 text-[#2D5A27] text-xs space-y-2">
          <div className="flex items-center gap-2 font-bold text-sm text-[#2D5A27]">
            <CheckCircle2 className="w-5 h-5 text-[#2D5A27] shrink-0" />
            <span>Currency Reserved Successfully!</span>
          </div>
          <p>
            Thank you, <strong className="font-semibold">{customerName}</strong>. We have reserved <strong className="font-semibold">{foreignAmount} {selectedCurrency}</strong> (£{calculatedGbp}) for you.
          </p>
          <div className="bg-white p-3 rounded-lg border border-stone-200 text-[11px] space-y-1 font-mono text-stone-700">
            <p>📍 Pickup Location: 97-99 Westminster Bridge Rd, SE1 7HR</p>
            <p>⏰ Open 24 Hours (Bring photo ID or Passport)</p>
            <p>📞 Reference Saved to: {customerPhone}</p>
          </div>
          <button
            onClick={() => setReservationSuccess(false)}
            className="text-xs font-bold text-[#2D5A27] underline pt-1"
          >
            Calculate another currency exchange
          </button>
        </div>
      )}
    </div>
  );
};
