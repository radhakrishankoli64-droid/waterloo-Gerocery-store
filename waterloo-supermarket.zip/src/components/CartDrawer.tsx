import React, { useState } from 'react';
import { CartItem } from '../types';
import { STORE_DETAILS } from '../data/storeInfo';
import { 
  X, 
  Trash2, 
  ShoppingBag, 
  Plus, 
  Minus, 
  Sparkles, 
  Clock, 
  MapPin, 
  Truck, 
  CheckCircle2, 
  Tag, 
  ArrowRight 
} from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onProceedToCheckout: (fulfillmentType: 'delivery' | 'pickup', promoDiscount: number) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToCheckout
}) => {
  const [fulfillmentType, setFulfillmentType] = useState<'delivery' | 'pickup'>('delivery');
  const [promoCode, setPromoCode] = useState('');
  const [promoDiscount, setPromoDiscount] = useState(0);
  const [promoApplied, setPromoApplied] = useState(false);
  const [promoError, setPromoError] = useState('');

  if (!isOpen) return null;

  const rawSubtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const discountAmount = (rawSubtotal * promoDiscount) / 100;
  const subtotalAfterDiscount = rawSubtotal - discountAmount;

  const isFreeDelivery = subtotalAfterDiscount >= STORE_DETAILS.freeDeliveryThreshold;
  const deliveryFee = fulfillmentType === 'delivery' ? (isFreeDelivery ? 0 : STORE_DETAILS.deliveryFee) : 0;
  const grandTotal = subtotalAfterDiscount + deliveryFee;

  const amountUntilFreeDelivery = Math.max(0, STORE_DETAILS.freeDeliveryThreshold - subtotalAfterDiscount);
  const progressPercent = Math.min(100, (subtotalAfterDiscount / STORE_DETAILS.freeDeliveryThreshold) * 100);

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    setPromoError('');
    if (promoCode.trim().toUpperCase() === 'WATERLOO10') {
      setPromoDiscount(10);
      setPromoApplied(true);
    } else if (promoCode.trim().toUpperCase() === 'WELCOME15') {
      setPromoDiscount(15);
      setPromoApplied(true);
    } else {
      setPromoError('Invalid code. Try WATERLOO10 for 10% off!');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="absolute inset-0" onClick={onClose} />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between border-l border-slate-200">
          
          {/* Cart Header */}
          <div className="p-4 sm:p-6 bg-stone-900 text-white flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-[#2D5A27] text-white flex items-center justify-center font-bold">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-serif font-bold">Your Shopping Cart</h2>
                <p className="text-xs text-stone-300">{cart.reduce((a, b) => a + b.quantity, 0)} Items Selected</p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 text-stone-400 hover:text-white rounded-lg hover:bg-stone-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Delivery threshold bar */}
          {cart.length > 0 && fulfillmentType === 'delivery' && (
            <div className="bg-[#F8F7F3] border-b border-stone-200 p-3 text-xs text-stone-900">
              {amountUntilFreeDelivery > 0 ? (
                <div>
                  <p className="font-semibold text-stone-800 mb-1">
                    Add <strong className="font-mono text-stone-950 font-bold">£{amountUntilFreeDelivery.toFixed(2)}</strong> more for <span className="underline decoration-[#2D5A27]">FREE SE1 Express Delivery</span>!
                  </p>
                  <div className="w-full bg-stone-200 rounded-full h-1.5 overflow-hidden">
                    <div
                      className="bg-[#2D5A27] h-1.5 rounded-full transition-all duration-300"
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 font-bold text-[#2D5A27]">
                  <CheckCircle2 className="w-4 h-4 text-[#2D5A27] shrink-0" />
                  <span>🎉 You qualified for FREE Express Local Delivery!</span>
                </div>
              )}
            </div>
          )}

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 divide-y divide-stone-100">
            {cart.length === 0 ? (
              <div className="text-center py-16 text-stone-400 space-y-3">
                <ShoppingBag className="w-12 h-12 mx-auto text-stone-300" />
                <p className="text-sm font-bold text-stone-700">Your cart is currently empty</p>
                <p className="text-xs text-stone-500 max-w-xs mx-auto">
                  Browse our fresh produce, drinks, bakery, and travel items to add products.
                </p>
                <button
                  onClick={onClose}
                  className="mt-2 px-4 py-2 bg-[#2D5A27] text-white rounded-lg text-xs font-bold"
                >
                  Start Shopping
                </button>
              </div>
            ) : (
              cart.map(({ product, quantity }) => (
                <div key={product.id} className="pt-4 first:pt-0 flex items-center gap-3">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-16 h-16 object-cover rounded-xl border border-stone-200 shrink-0"
                  />

                  <div className="flex-1 min-w-0">
                    <h4 className="text-xs font-bold text-stone-900 line-clamp-1">{product.name}</h4>
                    <p className="text-[11px] text-stone-500">{product.unit}</p>
                    <p className="text-xs font-bold text-[#2D5A27] font-mono mt-0.5">
                      £{(product.price * quantity).toFixed(2)}
                    </p>
                  </div>

                  {/* Quantity Controller */}
                  <div className="flex items-center gap-1 bg-stone-100 rounded-lg p-1 border border-stone-200 shrink-0">
                    <button
                      onClick={() => onUpdateQuantity(product.id, -1)}
                      className="p-1 text-stone-600 hover:text-stone-900 rounded hover:bg-white transition-colors"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-6 text-center text-xs font-bold text-stone-900">{quantity}</span>
                    <button
                      onClick={() => onUpdateQuantity(product.id, 1)}
                      className="p-1 text-stone-600 hover:text-stone-900 rounded hover:bg-white transition-colors"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>

                  <button
                    onClick={() => onRemoveItem(product.id)}
                    className="p-1.5 text-stone-400 hover:text-rose-600 transition-colors"
                    title="Remove item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}
          </div>

          {/* Cart Footer */}
          {cart.length > 0 && (
            <div className="p-4 sm:p-6 bg-[#F8F7F3] border-t border-stone-200 space-y-4">
              
              {/* Order Mode Switch */}
              <div className="grid grid-cols-2 gap-2 bg-stone-200 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => setFulfillmentType('delivery')}
                  className={`py-2 px-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                    fulfillmentType === 'delivery'
                      ? 'bg-white text-stone-900 shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <Truck className="w-3.5 h-3.5 text-[#2D5A27]" />
                  <span>30-Min SE1 Delivery</span>
                </button>

                <button
                  type="button"
                  onClick={() => setFulfillmentType('pickup')}
                  className={`py-2 px-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                    fulfillmentType === 'pickup'
                      ? 'bg-white text-stone-900 shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <MapPin className="w-3.5 h-3.5 text-amber-600" />
                  <span>15-Min Click & Collect</span>
                </button>
              </div>

              {/* Promo Code Input */}
              {!promoApplied ? (
                <form onSubmit={handleApplyPromo} className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Promo Code (WATERLOO10)"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                    className="flex-1 bg-white border border-stone-300 rounded-lg px-3 py-1.5 text-xs text-stone-900 uppercase font-mono outline-none focus:border-[#2D5A27]"
                  />
                  <button
                    type="submit"
                    className="px-3.5 py-1.5 bg-stone-800 text-white text-xs font-bold rounded-lg hover:bg-stone-900"
                  >
                    Apply
                  </button>
                </form>
              ) : (
                <div className="flex items-center justify-between text-xs bg-[#2D5A27]/10 border border-[#2D5A27]/20 p-2.5 rounded-lg text-[#2D5A27] font-bold">
                  <span className="flex items-center gap-1">
                    <Tag className="w-3.5 h-3.5 text-[#2D5A27]" />
                    {promoDiscount}% Promo Discount Applied
                  </span>
                  <button
                    onClick={() => {
                      setPromoApplied(false);
                      setPromoDiscount(0);
                    }}
                    className="text-[10px] text-rose-700 underline"
                  >
                    Remove
                  </button>
                </div>
              )}
              {promoError && <p className="text-[11px] text-rose-600 font-medium">{promoError}</p>}

              {/* Total Summary */}
              <div className="space-y-1.5 text-xs text-stone-600 pt-2 border-t border-stone-200">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-mono text-stone-900">£{rawSubtotal.toFixed(2)}</span>
                </div>

                {promoDiscount > 0 && (
                  <div className="flex justify-between text-[#2D5A27] font-semibold">
                    <span>Discount ({promoDiscount}%)</span>
                    <span className="font-mono">-£{discountAmount.toFixed(2)}</span>
                  </div>
                )}

                <div className="flex justify-between">
                  <span>
                    {fulfillmentType === 'delivery' ? 'Express SE1 Delivery Fee' : 'Store Click & Collect'}
                  </span>
                  <span className="font-mono text-stone-900">
                    {fulfillmentType === 'pickup' ? (
                      <span className="text-[#2D5A27] font-bold">FREE</span>
                    ) : isFreeDelivery ? (
                      <span className="text-[#2D5A27] font-bold">FREE</span>
                    ) : (
                      `£${deliveryFee.toFixed(2)}`
                    )}
                  </span>
                </div>

                <div className="flex justify-between text-base font-bold text-stone-900 pt-2 border-t border-stone-200">
                  <span>Total</span>
                  <span className="font-mono text-[#2D5A27] text-lg font-bold">£{grandTotal.toFixed(2)}</span>
                </div>
              </div>

              {/* Checkout Button */}
              <button
                onClick={() => onProceedToCheckout(fulfillmentType, promoDiscount)}
                className="w-full bg-[#2D5A27] hover:bg-[#23471f] text-white font-bold py-3.5 rounded-lg text-sm flex items-center justify-center gap-2 shadow-xs transition-all"
              >
                <span>Proceed to Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
